# Network Connectivity Diagnostics

## When to Use

Any platform/gateway connection failure where Hermes Gateway can't reach a messaging platform (Discord, Telegram, Slack, etc.) or an external API.

## Tiered Diagnostic Procedure

Start from Layer 1 and escalate only when the current layer is confirmed working.

### Layer 1: Gateway State & Logs

```bash
# Gateway status
hermes gateway status

# Recent errors in gateway log
grep -i "error\|fail\|timeout\|unauthorized" ~/.hermes/logs/gateway.log | tail -20

# Full error log
tail -30 ~/.hermes/logs/errors.log

# Gateway exit diagnostics
cat ~/.hermes/logs/gateway-exit-diag.log
```

**Check:** Is the gateway actually running? What error does Discord/Telegram show?

### Layer 2: DNS Resolution

```bash
nslookup discord.com
nslookup gateway.discord.gg
```

**Check:** Does DNS resolve to valid IPs (not NXDOMAIN, not localhost)?

### Layer 3: Direct HTTPS Connectivity

```bash
curl -v --connect-timeout 10 https://discord.com/api/v10/gateway
```

**Key signals:**
- `Connection was reset` during SSL handshake → **Active blocking** (GFW, firewall, ISP filter)
- `Connection timed out` after full timeout → **Packet loss or routing issue** (firewall drop, no route)
- `Could not resolve host` → **DNS failure** (Layer 2 issue)
- `SSL certificate problem` → **Certificate or SNI issue** (proxy intercept, ancient OS)
- 200/401 response → **Platform reachable**, problem is credentials or protocol

### Layer 4: Control Test (Cross-Reference)

Compare accessibility of known-blocked vs. known-accessible sites:

```bash
curl -s -o /dev/null -w "%{http_code}\n" --connect-timeout 5 https://baidu.com
curl -s -o /dev/null -w "%{http_code}\n" --connect-timeout 5 https://google.com
curl -s -o /dev/null -w "%{http_code}\n" --connect-timeout 5 https://github.com
```

If `baidu.com` works but `google.com` + `discord.com` both fail → **GFW / national firewall**.
If only `discord.com` fails → **Platform-specific block** (corporate firewall, rate limit).
If everything fails → **General network outage** (ISP down, no internet).

### Layer 5: Proxy & Route Check

```bash
# System proxy (Windows registry)
powershell -Command "Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable, ProxyServer -ErrorAction SilentlyContinue"

# Environment variables
echo "HTTP_PROXY=$HTTP_PROXY"
echo "HTTPS_PROXY=$HTTPS_PROXY"

# WinHTTP proxy
netsh winhttp show proxy

# Firewall
netsh advfirewall show allprofiles state

# Route trace (judiciously — may freeze on blocked IPs)
tracert -h 5 discord.com
```

### Layer 6: Process & Listening Ports

```bash
# Is the VPN/proxy client running?
ps -W | grep -iE "clash|v2ray|trojan|sslocal|tun|vpn|blueb"

# Are local proxy ports listening?
netstat -ano | grep -E "127.0.0.1:789|127.0.0.1:108|127.0.0.1:208"

# Check common TUN adapters
ipconfig | grep -A 2 -i "tun\|tap\|vpn"
```

## Common Blocking Signatures

| Pattern | Likely Cause | Fix |
|---------|-------------|-----|
| DNS OK, `Connection was reset` at SSL handshake | Actively blocked (GFW, firewall, ISP filter) | VPN/proxy |
| DNS OK, `Connection timed out` after 30s+ | Packet silently dropped (firewall rule, no route) | VPN/proxy or different network |
| DNS resolves to local IP (127.0.0.1, 0.0.0.0) | Hosts file hijack or local DNS poison | Check `/etc/hosts` |
| DNS fails (NXDOMAIN, server not responding) | DNS provider blocking | Switch DNS (8.8.8.8, 223.5.5.5) |

## Proxy Integration for Hermes Gateway

Once a local proxy is available (e.g. VPN client with SOCKS5/HTTP port):

1. Set environment variables for the gateway service:
   ```bash
   # In the gateway process environment or ~/.hermes/.env
   ALL_PROXY=socks5://127.0.0.1:10808
   HTTP_PROXY=http://127.0.0.1:10808
   HTTPS_PROXY=http://127.0.0.1:10808
   ```

2. Or set in Windows service (if nssm managed):
   ```bash
   nssm set HermesGateway AppEnvironmentExtra ALL_PROXY=socks5://127.0.0.1:10808
   ```

3. Restart the gateway: `hermes gateway restart` (or `schtasks /run /tn Hermes_Gateway`)

**Note:** Chinese VPN clients (Clash, v2ray, sing-box based) typically expose a `mixed` protocol port (usually 10808 or 7890) that handles both HTTP CONNECT and SOCKS5. Check the config files in `binConfigs/` for `inbounds[].port` to find the right port.

## Hermes Agent-Specific Notes

- Gateway logs are at `~/.hermes/logs/gateway.log`
- The gateway's Discord adapter uses discord.py / aiohttp, which respects `HTTP_PROXY`/`HTTPS_PROXY`/`ALL_PROXY` env vars
- Gateway restart via Scheduled Task on Windows: `schtasks /run /tn Hermes_Gateway`
- Gateway restart via CLI: `hermes gateway restart`
- CLI sessions are unaffected by gateway platform connectivity — they talk directly to the model provider, not through the gateway
- A gateway crash during Discord reconnection will make the Discord-side agent appear offline, but CLI sessions continue independently
