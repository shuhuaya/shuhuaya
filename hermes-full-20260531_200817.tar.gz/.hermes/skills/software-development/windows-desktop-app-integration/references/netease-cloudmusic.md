# NetEase Cloud Music (网易云音乐) — Windows Desktop Control

## Protocol

- **Protocol**: `orpheus://` (NOT `cloudmusic://`)
- **Registered at**: `HKCR\orpheus`
- **DefaultIcon**: `C:\Program Files\NetEase\CloudMusic\cloudmusic.exe,0`
- **Command**: `"C:\Program Files\NetEase\CloudMusic\cloudmusic.exe"--webcmd="%1"`
  - Note: no space between the exe closing quote and `--webcmd=`

## Song URL Format

```
orpheus://song?id=SONG_ID
```

## Getting Song ID

Use NetEase's search API:
```
curl -s "https://music.163.com/api/search/get?s=SONG_NAME&type=1&offset=0&total=true&limit=1" -H "Referer: https://music.163.com/"
```

The song ID is in the response under `result.songs[0].id`.

## Direct MP3 Stream URL

```
https://music.163.com/song/media/outer/url?id=SONG_ID
```
This redirects to a CDN MP3 URL. The CDN URL has expired tokens — get a fresh one per session.

## File Association (for --play)

```
.ncm = cloudmusic.ncm
cloudmusic.ncm = "C:\Program Files\NetEase\CloudMusic\cloudmusic.exe"--play="%1"
```

- Use `--play="filepath"` to open a local audio file in the client
- The `--play` flag may have limited playback (tested: ~3 seconds on external MP3)
- MP3 files on typical Windows installs are associated with Windows Media Player by default, not NetEase

## Installation Path

```
C:\Program Files\NetEase\CloudMusic\cloudmusic.exe
```

## Sub-process Architecture

The app uses Chromium Embedded Framework (CEF):
- Main process (no arguments)
- `--type=gpu-process` (GPU acceleration)
- `--type=renderer --no-sandbox` (web rendering)
- `--type=utility --utility-sub-type=audio.mojom.AudioService` (audio)

## Launching on Interactive Desktop

On Windows with Hermes, `Start-Process` from git-bash may launch the process in a non-interactive session. Use a scheduled task:

```powershell
$action = New-ScheduledTaskAction -Execute 'C:\Program Files\NetEase\CloudMusic\cloudmusic.exe'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)
Register-ScheduledTask -TaskName 'NetEaseDesktop' -Action $action -Trigger $trigger -User 'Administrator' -RunLevel Highest -Force
Start-ScheduledTask -TaskName 'NetEaseDesktop'
# Wait a moment, then clean up
Unregister-ScheduledTask -TaskName 'NetEaseDesktop' -Confirm:$false
```

## Triggering from Hermes Browser

1. Create HTML with link:
   ```html
   <a href="orpheus://song?id=SONG_ID">▶ Play</a>
   ```
2. Serve via local HTTP server (not file://):
   ```
   python3 -m http.server 8888 --directory "/c/Users/<user>/"
   ```
3. Navigate browser to `http://localhost:8888/player.html`
4. Click the link → triggers protocol handler → client plays song
