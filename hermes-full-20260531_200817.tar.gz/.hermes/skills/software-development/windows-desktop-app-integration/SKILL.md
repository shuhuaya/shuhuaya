---
name: windows-desktop-app-integration
description: Control Windows desktop applications from Hermes — launch GUI apps on the interactive desktop, trigger actions via custom URL protocol handlers through the Hermes browser.
tags: [windows, gui-apps, protocol-handlers, desktop, automation]
---

# Windows Desktop App Integration

Trigger and control Windows GUI desktop applications from Hermes Agent. This is useful when the user wants to **see** an app running on their desktop (not a background process) or wants an app to perform an action (like playing a song).

## Triggering App Actions via Custom URL Protocols

Many Windows desktop apps register custom URL protocol handlers (e.g., `spotify://`, `orpheus://`, `steam://`). You can trigger these from Hermes using the browser tool.

### Workflow

1. **Find the correct protocol** — check the registry:
   ```
   # Check HKCR first (machine-wide)
   cmd.exe //c "reg query HKCR\<protocol>" 
   
   # Try the app's internal codename, not just its brand name
   # NetEase Cloud Music uses "orpheus", not "cloudmusic"
   cmd.exe //c "reg query HKCR\orpheus /s"
   ```

2. **Verify the handler** — check the command template:
   ```
   HKCR\orpheus\shell\open\command
   (default) = "C:\Program Files\NetEase\CloudMusic\cloudmusic.exe"--webcmd="%1"
   ```
   Note: the argument format after `%1` may have no space between the exe and the flag.

3. **If protocol isn't registered**, register it:
   ```
   New-Item -Path 'HKCU:\Software\Classes\<protocol>' -Force
   Set-ItemProperty -Path 'HKCU:\Software\Classes\<protocol>' -Name '(default)' -Value 'URL:<protocol> Protocol'
   Set-ItemProperty -Path 'HKCU:\Software\Classes\<protocol>' -Name 'URL Protocol' -Value ''
   New-Item -Path 'HKCU:\Software\Classes\<protocol>\shell\open\command' -Force
   Set-ItemProperty -Path 'HKCU:\Software\Classes\<protocol>\shell\open\command' -Name '(default)' -Value '"C:\Path\App.exe" "%1"'
   ```

4. **Create an HTML page** with a link to the protocol URL:
   ```html
   <a href="orpheus://song?id=1875941511">▶ Play in App</a>
   ```

5. **Serve it via local HTTP server** (browser CORS restrictions block `file://`):
   ```
   python3 -m http.server 8888 --directory "/c/Users/<user>/"
   ```

6. **Navigate Hermes browser** to the page and **click the link**:
   ```
   browser_navigate(url='http://localhost:8888/launch.html')
   browser_click(ref='...')
   ```

### Finding the Correct URL Format

- Use `browser_console` to inspect links on the app's web page:
  ```
  browser_console(expression='document.querySelector(\'a[href*="protocol"]\')?.getAttribute(\'href\')')
  ```
- The web page's "open in app" button usually reveals the correct format.

## Launching GUI Apps on the Interactive Desktop

When you launch a GUI app from Hermes' terminal (running in a non-interactive context), the app may start but **not show a visible window** on the user's desktop.

### Use a Scheduled Task (reliable)

```powershell
# Create and run a one-time task
$action = New-ScheduledTaskAction -Execute 'C:\Path\App.exe'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)
Register-ScheduledTask -TaskName 'TempApp' -Action $action -Trigger $trigger -User 'Administrator' -RunLevel Highest -Force
Start-ScheduledTask -TaskName 'TempApp'
```

### Clean up after

```powershell
Unregister-ScheduledTask -TaskName 'TempApp' -Confirm:$false
```

### Direct PowerShell Start-Process (less reliable)

```powershell
Start-Process -FilePath 'C:\Path\App.exe' -WindowStyle Normal
```

## Passing Arguments to Desktop Apps

Check `.ncm` / app file type associations to discover argument formats:

```
cmd.exe //c "assoc .ncm"          # → .ncm=cloudmusic.ncm
cmd.exe //c "ftype cloudmusic.ncm" # → ...cloudmusic.exe"--play="%1"
```

This reveals flags like `--play="filepath"` or `--webcmd="url"`.

Then invoke:
```powershell
Start-Process -FilePath 'C:\Program Files\App\app.exe' -ArgumentList '--webcmd="protocol://action?param=value"'
```

## Pitfalls

- **Single-instance apps**: The app may already be running. New process forwards the URL via IPC and exits. No visible new process — check by inspecting the running process command lines.
- **Browser protocol navigation**: `browser_navigate(url='protocol://...')` fails because browsers can't navigate to custom protocols directly. Always use an intermediate HTML page with a clickable `<a>` link.
- **Auto-play blocked**: Browsers block `<audio autoplay>` without user interaction. Always include a play button.
- **file:// CORS**: You cannot `fetch()` external URLs from `file://` pages. Always use a local HTTP server.
- **Protocol names differ from brand names**: NetEase Cloud Music's protocol is `orpheus://` (internal codename), NOT `cloudmusic://`.
- **PowerShell 2> syntax**: In git-bash, the `2>nul` redirect doesn't work in PowerShell — use `2>$null` instead, or use `cmd.exe //c` for registry queries.
