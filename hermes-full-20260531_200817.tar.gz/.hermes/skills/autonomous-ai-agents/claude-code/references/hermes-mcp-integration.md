# Hermes Agent → Claude Code MCP Integration

Expose Hermes Agent to Claude Code via MCP so Claude can read/send messages across connected messaging platforms (Telegram, Discord, Slack) during coding sessions.

## Setup Steps

1. **Verify Hermes MCP serve works:**
   ```bash
   hermes mcp serve --help
   ```
   Tests on Hermes v1.27+.

2. **Register with Claude Code:**
   ```bash
   claude mcp add hermes -- hermes mcp serve
   ```
   For remote Hermes (VPS): `claude mcp add hermes -- ssh -T user@host hermes mcp serve`

3. **Verify connection:**
   ```bash
   claude mcp list
   # Expected: hermes: hermes mcp serve - ✓ Connected
   ```

4. **Test tools:**
   Ask Claude Code: "List my active Hermes conversations"
   Expected tools: `conversations_list`, `messages_read`, `messages_send`, `events_poll`, `channels_list`

## Common Failure: .env UTF-16 BOM

**Symptom:** `hermes mcp serve` crashes with `UnicodeDecodeError: 'utf-8' codec can't decode byte 0xff in position 0`

**Cause:** `pydantic_settings` auto-scans `.env` files in the working directory tree. Windows tools (notepad.exe, PowerShell) often save `.env` as UTF-16 LE with BOM (`0xFF 0xFE`). `python-dotenv` only reads UTF-8.

**Fix:** Scan and convert all corrupted `.env` files:
```bash
find /c/Users/Administrator /d -name ".env" -type f | while read f; do
  first=$(xxd -p -l2 "$f" 2>/dev/null)
  if [ "$first" = "fffe" ]; then
    python3 -c "
with open('$f', 'rb') as fh:
    raw = fh.read()
with open('$f', 'w', encoding='utf-8') as fh:
    fh.write(raw.decode('utf-16'))
"
    echo "Fixed: $f"
  fi
done
```

**Common victim files:** `C:\Users\<user>\.env`, `C:\Users\<user>\.codex\.env`, `D:\.env`, project-level `.env`

## MCP Config Location

When running `claude mcp add hermes -- hermes mcp serve`, the config is saved to `~/.claude.json` under the user's project scope. To make it available globally:
- The `claude mcp add` command saves to the current project's `mcpServers` in `.claude.json`
- If it only works from one directory, move the entry to the top-level `mcpServers` key in `.claude.json`

## Tools Exposed

Hermes MCP serve provides approximately 10 tools:
- `conversations_list` — list active conversations
- `messages_read` — read message history
- `messages_send` — send messages to a conversation
- `events_poll` — poll for new events/messages
- `channels_list` — list available channels
- Approve/reject pending command approvals
