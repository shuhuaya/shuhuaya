# Anthropic → OpenAI Proxy for Claude Code

让 Claude Code 使用非 Anthropic API 后端（如 OpenCode Go、任何 OpenAI 兼容 API）。

## 完整代理脚本

保存在 `D:\hermes\scripts\anthropic-to-opencode-proxy.py`。

### 启动方式

```bash
# 后台运行
python3 D:/hermes/scripts/anthropic-to-opencode-proxy.py

# 使用 Claude Code
export ANTHROPIC_BASE_URL=http://127.0.0.1:8080
export ANTHROPIC_API_KEY=<your-key>
claude -p '你的任务'
```

### 环境变量

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `OPENCODE_BASE_URL` | `https://opencode.ai/zen/go/v1` | 后端 API 地址 |
| `OPENCODE_API_KEY` | 从 `auth.json` 读取 | API 密钥 |
| `PROXY_PORT` | `8080` | 代理监听端口 |
| `PROXY_LOG` | `D:\hermes\scripts\proxy.log` | 日志文件路径 |

### 模型映射（默认）

| Anthropic 模型名 | 实际调用的模型 |
|---|---|
| `claude-sonnet-4` | `deepseek-v4-flash` |
| `claude-opus-4` | `deepseek-v4-pro` |
| `deepseek-v4-flash` | `deepseek-v4-flash` |

### API 格式转换

**Anthropic 请求（收到）：**
```json
{
  "model": "claude-sonnet-4",
  "max_tokens": 4096,
  "messages": [
    {"role": "user", "content": "你好"}
  ],
  "stream": false
}
```

**OpenAI 请求（发出）：**
```json
{
  "model": "deepseek-v4-flash",
  "max_tokens": 4096,
  "messages": [
    {"role": "user", "content": "你好"}
  ],
  "stream": false
}
```

**Anthropic 响应（返回）：**
```json
{
  "id": "msg_xxx",
  "type": "message",
  "role": "assistant",
  "content": [{"type": "text", "text": "你好！"}],
  "model": "deepseek-v4-flash",
  "stop_reason": "end_turn",
  "usage": {"input_tokens": 10, "output_tokens": 5}
}
```

### 流式转换

OpenAI SSE `data: {"choices": [{"delta": {"content": "你"}}]}` → Anthropic SSE `event: content_block_delta\ndata: {"delta": {"text": "你"}}`

### 已知问题与解决方案

| 问题 | 原因 | 解决 |
|------|------|------|
| `HTTP Error 403: Forbidden` | Python urllib 的 User-Agent 被 Cloudflare 拦截 | 设置 `User-Agent: curl/8.19.0` |
| 错误信息为空字符串 | HTTPError body 被读了两次 | 用自定义异常类包装 body，只读一次 |
| `do_POST` 未被调用 | 端口上有旧进程残留 | `netstat -ano \| find "8080"` 查 PID 后 kill |
| `OPENGODE_KEY` 为空但 `auth.json` 存在 | 模块级变量在 `main()` 之前就已赋值 | 在 `main()` 中用 `global OPENGODE_KEY` 更新 |
