---
name: codex
description: "Delegate coding to OpenAI Codex CLI (features, PRs)."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, Codex, OpenAI, Code-Review, Refactoring]
    related_skills: [claude-code, hermes-agent]
---

# Codex CLI

Delegate coding tasks to [Codex](https://github.com/openai/codex) via the Hermes terminal. Codex is OpenAI's autonomous coding agent CLI.

## When to use

- Building features
- Refactoring
- PR reviews
- Batch issue fixing

Requires the codex CLI and a git repository.

## Prerequisites

- Codex installed: `npm install -g @openai/codex`
- OpenAI auth configured: either `OPENAI_API_KEY` or Codex OAuth credentials
  from the Codex CLI login flow
- **Must run inside a git repository** — Codex refuses to run outside one
- Use `pty=true` in terminal calls — Codex is an interactive terminal app

For Hermes itself, `model.provider: openai-codex` uses Hermes-managed Codex
OAuth from `~/.hermes/auth.json` after `hermes auth add openai-codex`. For the
standalone Codex CLI, a valid CLI OAuth session may live under
`~/.codex/auth.json`; do not treat a missing `OPENAI_API_KEY` alone as proof
that Codex auth is missing.

## Codex API Version Gotchas

**Codex v0.122.0+ removed `wire_api = "chat"` support.** All versions from
at least v0.100.0 onward only speak the **Responses API** (`/v1/responses`),
not the Chat Completions API (`/v1/chat/completions`). Setting
`wire_api = "chat"` in `config.toml` is rejected with:

```
`wire_api = "chat"` is no longer supported.
How to fix: set `wire_api = "responses"` in your provider config.
```

If your provider only supports Chat Completions (e.g. OpenCode Go, DeepSeek,
SiliconFlow), you **cannot** use it as a Codex model provider without a
translation bridge. The bridge translates `/v1/responses` requests into
`/v1/chat/completions` calls and back.

### SSE Streaming Required

Codex always sends `stream: true` in Responses API requests. It opens an SSE
(Server-Sent Events) connection and expects:

1. `event: response.output_text.delta` — one or more events with partial text
2. `event: response.completed` — final event with the full response object

If the bridge returns plain JSON instead of SSE events, Codex retries 5 times
and then fails with:

```
ERROR: stream disconnected before completion: stream closed before response.completed
```

**Fix:** The bridge MUST respond with `Content-Type: text/event-stream` and emit
proper SSE events. See `references/codex-responses-bridge.md` for a complete
SSE-enabled implementation.

### Cloudflare Blocks Python urllib

If your provider sits behind Cloudflare, Python's `urllib.request` gets HTTP
403 with `error code: 1010` (WAF block). **Fix:** override the User-Agent
header to mimic a browser:

```python
headers = {
    "Authorization": f"Bearer {KEY}",
    "Content-Type": "application/json",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
}
```

### Complex Input Format

The Responses API `input` field can be:

- **A string**: `"say hello"` — straightforward
- **An array of message objects**:
  ```json
  [{"role": "user", "content": [{"type": "input_text", "text": "say hello"}]}]
  ```

The bridge must handle both. See the reference file for extraction logic.

### Token env-var redaction

Hermes automatically redacts credential strings (`sk-...`, `github_pat_...`)
from tool inputs and outputs. You cannot pass API keys directly in terminal
commands or `write_file` content. Workaround: read the key from `.hermes/.env`
in a Python script and write it to a file (`~/.codex_bridge_key`) that the
bridge reads at startup.

## Registering Hermes MCP with Codex

Codex supports MCP servers via `codex mcp` subcommands, similar to Claude Code:

```bash
codex mcp add hermes -- hermes mcp serve
codex mcp list   # verify: hermes: enabled
```

If Codex's config loads a broken model provider (e.g. `ollama-local` not
defined), override it inline:

```bash
codex -c model_provider=openai mcp add hermes -- hermes mcp serve
```

If you have multiple `config.toml` files in different search paths (e.g.
`~/.codex/` and `D:\Administrator\.codex\`), fix all of them — Codex may
load more than one and fail on the first broken entry.

## Custom Provider Bridge (Responses → Chat Completions)

When your provider doesn't support the Responses API, run a local HTTP bridge:

```python
# D:/codex_bridge.py — full example in references/codex-responses-bridge.md
# Reads key from ~/.codex_bridge_key (to bypass Hermes token redaction)
# Translates POST /v1/responses → POST /v1/chat/completions with SSE streaming
# Handles GET /v1/models for model discovery
```

**Critical:** The bridge MUST emit SSE events (see "SSE Streaming Required"
above). A plain JSON response causes Codex to fail with `stream disconnected`.

Configure Codex to point at the bridge:

```toml
# ~/.codex/config.toml
model = "deepseek-v4-flash"
model_provider = "opencode-go"

[model_providers.opencode-go]
name = "OpenCode Go"
base_url = "http://127.0.0.1:8899"  # ← bridge address
env_key = "OPENAI_API_KEY"
```

Start the bridge before running Codex:

```bash
# Linux / macOS
python3 D:/codex_bridge.py &
sleep 2
curl http://127.0.0.1:8899/v1/models          # verify

# Windows (in terminal with background=true)
terminal(command="python -u D:/codex_bridge.py 8899", background=true)
# Use a log file for visibility on Windows:
# python -u D:/run_bridge.py  (see reference file)

# Stop bridge on Windows
taskkill //F //PID <PID>

# Check what's listening on the bridge port
netstat -ano | grep ":8899" | grep LISTENING
```

**Windows process gotcha:** Start the bridge with `background=true` in a
separate terminal call; do NOT use shell-level `&` backgrounding (tool rejects
it). stdout from child processes may not be captured by Hermes; redirect to
a log file for debugging.

## One-Shot Tasks

```
terminal(command="codex exec 'Add dark mode toggle to settings'", workdir="~/project", pty=true)
```

For scratch work (Codex needs a git repo):
```
terminal(command="cd $(mktemp -d) && git init && codex exec 'Build a snake game in Python'", pty=true)
```

## Background Mode (Long Tasks)

```
# Start in background with PTY
terminal(command="codex exec --full-auto 'Refactor the auth module'", workdir="~/project", background=true, pty=true)
# Returns session_id

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send input if Codex asks a question
process(action="submit", session_id="<id>", data="yes")

# Kill if needed
process(action="kill", session_id="<id>")
```

## Key Flags

| Flag | Effect |
|------|--------|
| `exec "prompt"` | One-shot execution, exits when done |
| `--full-auto` | Sandboxed but auto-approves file changes in workspace |
| `--yolo` | No sandbox, no approvals (fastest, most dangerous) |

## PR Reviews

Clone to a temp directory for safe review:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && gh pr checkout 42 && codex review --base origin/main", pty=true)
```

## Parallel Issue Fixing with Worktrees

```
# Create worktrees
terminal(command="git worktree add -b fix/issue-78 /tmp/issue-78 main", workdir="~/project")
terminal(command="git worktree add -b fix/issue-99 /tmp/issue-99 main", workdir="~/project")

# Launch Codex in each
terminal(command="codex --yolo exec 'Fix issue #78: <description>. Commit when done.'", workdir="/tmp/issue-78", background=true, pty=true)
terminal(command="codex --yolo exec 'Fix issue #99: <description>. Commit when done.'", workdir="/tmp/issue-99", background=true, pty=true)

# Monitor
process(action="list")

# After completion, push and create PRs
terminal(command="cd /tmp/issue-78 && git push -u origin fix/issue-78")
terminal(command="gh pr create --repo user/repo --head fix/issue-78 --title 'fix: ...' --body '...'")

# Cleanup
terminal(command="git worktree remove /tmp/issue-78", workdir="~/project")
```

## Batch PR Reviews

```
# Fetch all PR refs
terminal(command="git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'", workdir="~/project")

# Review multiple PRs in parallel
terminal(command="codex exec 'Review PR #86. git diff origin/main...origin/pr/86'", workdir="~/project", background=true, pty=true)
terminal(command="codex exec 'Review PR #87. git diff origin/main...origin/pr/87'", workdir="~/project", background=true, pty=true)

# Post results
terminal(command="gh pr comment 86 --body '<review>'", workdir="~/project")
```

## Rules

1. **Always use `pty=true`** — Codex is an interactive terminal app and hangs without a PTY
2. **Git repo required** — Codex won't run outside a git directory. Use `mktemp -d && git init` for scratch
3. **Use `exec` for one-shots** — `codex exec "prompt"` runs and exits cleanly
4. **`--full-auto` for building** — auto-approves changes within the sandbox
5. **Background for long tasks** — use `background=true` and monitor with `process` tool
6. **Don't interfere** — monitor with `poll`/`log`, be patient with long-running tasks
7. **Parallel is fine** — run multiple Codex processes at once for batch work
