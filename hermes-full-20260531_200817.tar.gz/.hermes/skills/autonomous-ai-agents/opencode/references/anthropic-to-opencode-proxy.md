# Anthropic → OpenCode Go 翻译代理

让 Claude Code 用 OpenCode Go 的 API 密钥运行。

## 原理

Claude Code 使用 Anthropic Messages API 格式（`POST /v1/messages`），而 OpenCode Go 提供的是 OpenAI Chat Completions 格式的 API。需要一个本地代理做协议转换。

```
Claude Code → [HTTP] → 本地代理 → [OpenAI格式] → opencode.ai/zen/go/v1
                 :8080
```

## 已知限制

- **密钥权限问题**：`opencode` 和 `opencode-go` 是两个不同订阅层的提供商，即使密钥值相同，`opencode-go` 的密钥不一定能访问 `opencode` 下的 Claude 模型
- **Cloudflare 拦截**：API 端点会拦截 Python `urllib` 默认 User-Agent，需设置为 `curl/8.19.0`
- **端口冲突**：Windows 上端口 8080 容易被占用，换端口或先清理旧进程

## 配置

```bash
export ANTHROPIC_BASE_URL=http://127.0.0.1:8080
export ANTHROPIC_API_KEY=<任意值，代理会忽略>
claude -p '你的任务'
```

## 关键端点信息

- **Base URL**: `https://opencode.ai/zen/go/v1`（通过 `opencode debug config` 查到）
- **Auth 文件**: `~/.local/share/opencode/auth.json`
- **模型列表**: `opencode models opencode-go` / `opencode models opencode`

## 完整实现

见 `D:\hermes\scripts\anthropic-to-opencode-proxy.py`（或同目录下的最新版本）
