---
name: opencode
description: "Delegate coding to OpenCode CLI (features, PR review)."
version: 1.3.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, OpenCode, Autonomous, Refactoring, Code-Review]
    related_skills: [claude-code, codex, hermes-agent]
---

# OpenCode CLI

Use [OpenCode](https://opencode.ai) as an autonomous coding worker orchestrated by Hermes terminal/process tools. OpenCode is a provider-agnostic, open-source AI coding agent with a TUI and CLI.

## When to Use

- User explicitly asks to use OpenCode
- You want an external coding agent to implement/refactor/review code
- You need long-running coding sessions with progress checks
- You want parallel task execution in isolated workdirs/worktrees

## Prerequisites

- OpenCode installed: `npm i -g opencode-ai@latest` or `brew install anomalyco/tap/opencode`
- Auth configured: `opencode auth login` or set provider env vars (OPENROUTER_API_KEY, etc.)
- Verify: `opencode auth list` should show at least one provider
- Git repository for code tasks (recommended)
- `pty=true` for interactive TUI sessions

## Binary Resolution (Important)

Shell environments may resolve different OpenCode binaries. If behavior differs between your terminal and Hermes, check:

```
terminal(command="which -a opencode")
terminal(command="opencode --version")
```

If needed, pin an explicit binary path:

```
terminal(command="$HOME/.opencode/bin/opencode run '...'", workdir="~/project", pty=true)
```

## One-Shot Tasks

Use `opencode run` for bounded, non-interactive tasks:

```
terminal(command="opencode run 'Add retry logic to API calls and update tests'", workdir="~/project")
```

Attach context files with `-f`:

```
terminal(command="opencode run 'Review this config for security issues' -f config.yaml -f .env.example", workdir="~/project")
```

Show model thinking with `--thinking`:

```
terminal(command="opencode run 'Debug why tests fail in CI' --thinking", workdir="~/project")
```

Force a specific model:

```
terminal(command="opencode run 'Refactor auth module' --model openrouter/anthropic/claude-sonnet-4", workdir="~/project")
```

### Model Selection – Provider/Model Format

Model flag uses `provider/model` format. Discover what's available:

```
# List all providers with credentials
opencode auth list

# List models for a specific provider
opencode models opencode
opencode models opencode-go
opencode models deepseek

# See resolved config with API base URLs
opencode debug config
```

**Built-in providers and what they offer:**

| Provider | Model Types | Access |
|----------|------------|--------|
| `opencode` | Claude (sonnet/opus/haiku), GPT, Gemini | Subscription-gated, separate from opencode-go key |
| `opencode-go` | DeepSeek, Qwen, Kimi, GLM, MiniMax, Mimo | Same key as `opencode` but different subscription tier |
| `deepseek` | DeepSeek models | Direct DeepSeek API, needs separate key |

**Key insight:** the `opencode` and `opencode-go` providers often share the same API key in `~/.local/share/opencode/auth.json` but grant access to different model catalogs. `opencode-go/deepseek-v4-flash` is the most broadly available model. If `opencode/claude-sonnet-4` returns "Model not supported", the key's subscription doesn't include Claude access.

### Anthropic→OpenAI Proxy Pattern

Claude Code (Anthropic Messages API) cannot directly use OpenAI-compatible keys. If you only have an OpenAI-compatible key (like opencode-go), you need a translation proxy:

1. A local HTTP server that accepts Anthropic-format requests (`POST /v1/messages`)
2. Translates to OpenAI Chat Completions format
3. Forwards to the OpenAI-compatible endpoint
4. Translates responses back

Reference implementation: `references/anthropic-to-opencode-proxy.md`

**Limitations discovered:**
- The OpenCode Go API (`https://opencode.ai/zen/go/v1`) blocks Python `urllib`'s default User-Agent (Cloudflare 403). Must set `User-Agent: curl/8.19.0`.
- Base URL is visible via `opencode debug config` → nested under `provider.opencode.options.baseURL`
- Adding a translation proxy adds latency and complexity; prefer using `opencode run` directly when possible

## Interactive Sessions (Foreground / Direct TUI)

When the user asks to "open OpenCode on the desktop" or wants to interact directly with the TUI themselves, launch it in the foreground with `pty=true` and a generous timeout. The user gets full keyboard control and sees the TUI in their terminal:

```
terminal(command="opencode", workdir="~/project", pty=true, timeout=600)
```

- Use `workdir` to set the starting directory (e.g., `Desktop`, a project folder).
- The session runs until the user presses Ctrl+C (exit code 130) or the timeout elapses.
- No `process()` management needed — the user drives the TUI themselves.
- Only use this pattern when the user explicitly wants to interact (e.g. "打开到桌面", "启动交互", "我要用").

## Interactive Sessions (Background)

For iterative work requiring multiple exchanges where *you* (the agent) manage the session, start the TUI in background:

```
terminal(command="opencode", workdir="~/project", background=true, pty=true)
# Returns session_id

# Send a prompt
process(action="submit", session_id="<id>", data="Implement OAuth refresh flow and add tests")

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send follow-up input
process(action="submit", session_id="<id>", data="Now add error handling for token expiry")

# Exit cleanly — Ctrl+C
process(action="write", session_id="<id>", data="\x03")
# Or just kill the process
process(action="kill", session_id="<id>")
```

**Important:** Do NOT use `/exit` — it is not a valid OpenCode command and will open an agent selector dialog instead. Use Ctrl+C (`\x03`) or `process(action="kill")` to exit.

### TUI Keybindings

| Key | Action |
|-----|--------|
| `Enter` | Submit message (press twice if needed) |
| `Tab` | Switch between agents (build/plan) |
| `Ctrl+P` | Open command palette |
| `Ctrl+X L` | Switch session |
| `Ctrl+X M` | Switch model |
| `Ctrl+X N` | New session |
| `Ctrl+X E` | Open editor |
| `Ctrl+C` | Exit OpenCode |

### Resuming Sessions

After exiting, OpenCode prints a session ID. Resume with:

```
terminal(command="opencode -c", workdir="~/project", background=true, pty=true)  # Continue last session
terminal(command="opencode -s ses_abc123", workdir="~/project", background=true, pty=true)  # Specific session
```

## Common Flags

| Flag | Use |
|------|-----|
| `run 'prompt'` | One-shot execution and exit |
| `--continue` / `-c` | Continue the last OpenCode session |
| `--session <id>` / `-s` | Continue a specific session |
| `--agent <name>` | Choose OpenCode agent (build or plan) |
| `--model provider/model` | Force specific model |
| `--format json` | Machine-readable output/events |
| `--file <path>` / `-f` | Attach file(s) to the message |
| `--thinking` | Show model thinking blocks |
| `--variant <level>` | Reasoning effort (high, max, minimal) |
| `--title <name>` | Name the session |
| `--attach <url>` | Connect to a running opencode server |

## Procedure

1. Verify tool readiness:
   - `terminal(command="opencode --version")`
   - `terminal(command="opencode auth list")`
2. For bounded tasks, use `opencode run '...'` (no pty needed).
3. **If the user wants to drive OpenCode directly** ("打开到桌面", "我要用", "启动交互"), launch in foreground with `pty=true` and `timeout=600`. Do NOT use background mode — the user needs the TUI in their terminal.
4. For iterative tasks where *you* manage the session, start `opencode` with `background=true, pty=true`.
5. Monitor long tasks with `process(action="poll"|"log")`.
6. If OpenCode asks for input, respond via `process(action="submit", ...)`.
7. Exit with `process(action="write", data="\x03")` or `process(action="kill")`.
8. Summarize file changes, test results, and next steps back to user.

## PR Review Workflow

OpenCode has a built-in PR command:

```
terminal(command="opencode pr 42", workdir="~/project", pty=true)
```

Or review in a temporary clone for isolation:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && opencode run 'Review this PR vs main. Report bugs, security risks, test gaps, and style issues.' -f $(git diff origin/main --name-only | head -20 | tr '\n' ' ')", pty=true)
```

## Parallel Work Pattern

Use separate workdirs/worktrees to avoid collisions:

```
terminal(command="opencode run 'Fix issue #101 and commit'", workdir="/tmp/issue-101", background=true, pty=true)
terminal(command="opencode run 'Add parser regression tests and commit'", workdir="/tmp/issue-102", background=true, pty=true)
process(action="list")
```

## Auth Provider Management

OpenCode stores provider credentials. Three commands manage them:

### List configured providers

```
terminal(command="opencode auth list")
```

Shows all logged-in providers (e.g. OpenCode Zen, OpenCode Go, custom endpoints).

### Login to a provider

```
terminal(command="opencode auth login")
```

Or login to a custom OpenCode server:

```
terminal(command="opencode auth login https://my-opencode-server.com")
```

### Logout from a provider

**Important:** `opencode auth logout` is INTERACTIVE — it shows a TUI picker to select which provider to remove. Use `pty=true`:

```
terminal(command="opencode auth logout", pty=true)
```

Then use `process(action="submit", ...)` or pipe input to select the provider.

Alternatively, pipe selection directly (selects the first provider):

```
terminal(command="printf '\\n' | opencode auth logout", pty=true)
```

Or for multiple sequential logouts, pipe multiple newlines:

```
terminal(command="printf '\\n\\n' | opencode auth logout", pty=true)
```

### Manual auth file manipulation (fallback)

If the interactive logout isn't working, the auth file lives at:

- **Linux/macOS**: `~/.local/share/opencode/auth.json`
- **Windows**: `%LOCALAPPDATA%\\opencode\\auth.json` or `~/.local/share/opencode/auth.json`

Delete or edit this file to remove credentials directly. Look at the `auth list` output to see the file path:

```
┌  Credentials ~\\.local\\share\\opencode\\auth.json
```

### Re-login after logout

After logout, providers need to be re-authenticated:

1. `opencode auth login` — interactive OAuth/API-key flow
2. Or set env vars (`OPENCODE_ZEN_API_KEY`, `OPENCODE_GO_API_KEY`, etc.) and restart OpenCode

## Session & Cost Management

List past sessions:

```
terminal(command="opencode session list")
```

Check token usage and costs:

```
terminal(command="opencode stats")
terminal(command="opencode stats --days 7 --models anthropic/claude-sonnet-4")
```

## Pitfalls

- Interactive `opencode` (TUI) sessions require `pty=true`. The `opencode run` command does NOT need pty.
- `/exit` is NOT a valid command — it opens an agent selector. Use Ctrl+C to exit the TUI.
- PATH mismatch can select the wrong OpenCode binary/model config.
- If OpenCode appears stuck, inspect logs before killing:
  - `process(action="log", session_id="<id>")`
- Avoid sharing one working directory across parallel OpenCode sessions.
- Enter may need to be pressed twice to submit in the TUI (once to finalize text, once to send).
- **Direct API access from Python urllib gets Cloudflare 403** — the API endpoint (`https://opencode.ai/zen/go/v1`) blocks Python's default User-Agent. When making direct HTTP calls (not through the `opencode` CLI), always set `User-Agent: curl/8.19.0` in the request headers.
- **Key scoping** — the `opencode` and `opencode-go` entries in `~/.local/share/opencode/auth.json` may share the same key value but give access to different model catalogs. If you need Claude models, check that the key has `opencode` (not just `opencode-go`) subscription.
- **`opencode run` treats the message as a positional argument** — pass the prompt as a quoted string after `run`, not as `--command`.

## Verification

Smoke test:

```
terminal(command="opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'")
```

Success criteria:
- Output includes `OPENCODE_SMOKE_OK`
- Command exits without provider/model errors
- For code tasks: expected files changed and tests pass

## Rules

1. Prefer `opencode run` for one-shot automation — it's simpler and doesn't need pty.
2. **When the user says "打开" or "启动到桌面" — use foreground `pty=true` TUI, not background.** Background is for agent-managed sessions.
3. Use interactive background mode only when iteration is needed and the agent manages the session.
4. Always scope OpenCode sessions to a single repo/workdir.
5. For long tasks, provide progress updates from `process` logs.
6. Report concrete outcomes (files changed, tests, remaining risks).
7. Exit interactive sessions with Ctrl+C or kill, never `/exit`.
