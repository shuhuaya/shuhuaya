# GitHub Token Scope Diagnosis

Quick commands to check what a GitHub personal access token (PAT) can do — without exposing the token value.

## Quick Scope Check

```bash
source ~/.hermes/.env && TK=$GITHUB_TOKEN && curl -s -I \
  -H "Authorization: Bearer *** \
  "https://api.github.com/user" 2>&1 | grep -i x-oauth-scopes
```

Sample output: `x-oauth-scopes: repo, workflow, read:org`

If `repo` is in the list → token can create private repos, push, manage secrets, etc.
If `repo` is missing → read-only or limited scopes.

## Detailed Permission Check

```bash
source ~/.hermes/.env && TK=$GITHUB_TOKEN && \
  echo "--- User Info ---" && \
  curl -s -H "Authorization: Bearer *** https://api.github.com/user | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print(f'Login: {d.get(\"login\",\"?\")}\nPlan: {d.get(\"plan\",{}).get(\"name\",\"free\")}')" && \
  echo "--- Scopes ---" && \
  curl -s -I -H "Authorization: Bearer *** https://api.github.com/user 2>&1 | grep -i x-oauth-scopes
```

## Test Repo Creation

```bash
source ~/.hermes/.env && TK=$GITHUB_TOKEN && \
  curl -s -X POST -H "Authorization: Bearer *** \
  -H "Accept: application/vnd.github.v3+json" \
  "https://api.github.com/user/repos" \
  -d '{"name":"test-permissions-check","private":true,"auto_init":false}' | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print('OK' if d.get('html_url') else f'FAIL: {d.get(\"message\",d)}')"
```

Delete the test repo afterward:
```bash
source ~/.hermes/.env && TK=$GITHUB_TOKEN && \
  curl -s -X DELETE -H "Authorization: Bearer *** \
  "https://api.github.com/repos/$(source ~/.hermes/.env && echo $GITHUB_USER)/test-permissions-check"
```

## Common Scopes & Their Power

| Scope | What it grants |
|-------|---------------|
| `repo` | Full private repo access: push, create, delete, manage |
| `workflow` | Manage GitHub Actions |
| `read:org` | Read org membership and repos |
| `admin:repo_hook` | Manage webhooks |
| `delete_repo` | Delete repos |
| `user` | Read/write profile data |

## When Push Fails

If `git push` fails with `Repository not found` or `403`:
1. Does the repo exist? Check: `curl -s -H "Authorization: Bearer *** https://api.github.com/repos/owner/name | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('html_url',d.get('message','?')))"`
2. Does the token have `repo` scope? Run the scope check above.
3. Is the token expired? Check at https://github.com/settings/tokens
