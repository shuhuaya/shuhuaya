# Fine-Grained PATs vs Classic PATs

GitHub has two types of Personal Access Tokens. They behave differently with the API.

## Quick Identification

| Prefix | Type | Format |
|--------|------|--------|
| `ghp_` | Classic PAT | `ghp_xxxxxxxxxxxxxxxxxxxx` |
| `github_pat_` | Fine-grained PAT | `github_pat_11AAABBB...` |

## Scope vs Permissions

**Classic PAT (`ghp_`)** uses OAuth scopes:

```
x-oauth-scopes: repo, workflow, read:org
```

- `repo` scope → can create, push to, and manage private repos
- `workflow` scope → manage Actions
- Visible in the `X-OAuth-Scopes` response header

**Fine-grained PAT (`github_pat_`)** uses granular permissions per resource type:

```
x-oauth-scopes: none   ← ALWAYS returns this regardless of what it can do
```

- Permissions are set per-category: Contents, Issues, Pull requests, Administration, etc.
- **Always returns `X-OAuth-Scopes: none`** in headers — do NOT use this to diagnose access level
- To create repos, needs "Create repositories" permission under Account permissions
- Each permission can be "Read-only" or "Read and write"
- Can be scoped to specific repos only (not all repos)

## Common Failure: Cannot Create Repository

```json
{"message":"Resource not accessible by personal access token","status":"403"}
```

A classic PAT with `repo` scope can always create repos. A fine-grained PAT needs the **"Create repositories" account permission** explicitly enabled at:
https://github.com/settings/tokens → select the token → Repository access → All repositories → Account permissions → Create repositories → Read and write

## Diagnosis Commands

### Check token type
```bash
echo "${TOKEN:0:4}"
# "ghp_" = classic, "gith" = fine-grained (starts "github_pat_")
```

### Test what the token can do
```bash
# Can it authenticate? (works for both types)
curl -s -H "Authorization: Bearer $TOKEN" https://api.github.com/user | python3 -c "import sys,json; print(json.load(sys.stdin).get('login','FAIL'))"

# Can it create a repo? (classic with repo scope: yes / fine-grained: only if granted)
curl -s -X POST -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -d '{"name":"test-create-check","private":true}' \
  https://api.github.com/user/repos | python3 -c "import sys,json; r=json.load(sys.stdin); print('OK' if r.get('id') else r.get('message','?'))"

# List repos the token can see
curl -s -H "Authorization: Bearer $TOKEN" https://api.github.com/user/repos?per_page=5 \
  | python3 -c "import sys,json; [print(r['name']) for r in json.load(sys.stdin) if isinstance(r,dict)]"
```

## What Works Without Changes

| Operation | Classic PAT | Fine-grained PAT |
|-----------|-------------|-----------------|
| Authenticate (`/user`) | ✅ | ✅ |
| Read public repos | ✅ | ✅ |
| Push to repos (if granted) | ✅ (with `repo` scope) | ✅ (with Contents: Write) |
| Create repos | ✅ (with `repo` scope) | ❌ (needs explicit Account permission) |
| Delete repos | ✅ (with `delete_repo` scope) | ❌ (needs explicit Account permission) |
| Read user profile | ✅ | ✅ |
| Add SSH keys | ❌ (needs `user` scope) | ❌ (needs Account: SSH keys permission) |

## Fallback Strategy

If the provided fine-grained PAT cannot create repos:
1. Use `gh` CLI if installed (`gh repo create` uses the same token but via GraphQL — fails identically)
2. Use SSH key for git operations (SSH push doesn't need repo creation permission)
3. Ask user to either:
   a. Create repo manually at https://github.com/new
   b. Upgrade PAT permissions at https://github.com/settings/tokens
4. Or fall back to local archive (tar.gz) if GitHub is unavailable
