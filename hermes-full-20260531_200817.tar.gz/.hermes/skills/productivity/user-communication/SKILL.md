---
name: user-communication
description: Rules for how to communicate with the user — language, tone, verbosity, formatting. Loaded when interacting with users who have specific communication preferences.
version: 1.3.0
author: Hermes Agent
tags: [communication, language, style, formatting, user-preference]
trigger:
  - User said "用中文" / "不说英文" / "以后全部说中文"
  - User said "简洁" / "不要啰嗦" / "别说那么多" / "极度简洁"
  - User said "不要贴代码" or similar formatting corrections
  - User said "一劳永逸不要让我来" / "不要手动操作"
  - User said "任务时一定要使用看板功能"
  - User said "权限我都给你" / "不要暴力" / "合理的办法"
  - User said "先去学习一下" / "不能只是自己推理" / "先调研"
---

# User Communication

## Language: 全中文 Only

**All responses must be in 中文 (Chinese).** No English words, phrases, or terms — quote technical terms in Chinese description only. This is ABSOLUTE, not a suggestion.

When user corrects your language ("不说英文", "全部说中文"), switch immediately and save to memory. Do not use English even in parentheses or quotes.

## Concision: 极度简洁

- **Only** describe what was done and the outcome. No process description, no explanation.
- **Never** show code blocks, JSON, raw terminal output, curl commands, or command dumps.
- Format: "做了什么 → 结果如何". One sentence per result. Max 3 lines per topic.
- Example: "✅ 备份推送成功，远程分支已更新" — NOT "ran the script, which called git push..."
- Example: "仓库已创建" — NOT "curl returned HTTP 201 with body..."

## No Manual Steps (一劳永逸)

- Never ask the user to perform manual operations (edit files, create tokens, run commands).
- If a step genuinely requires user action, find an alternative approach first.
- If no alternative exists, state the single required action in one Chinese sentence — don't list step-by-step instructions.

## Kanban Required (看板必用)

- All multi-step tasks MUST use the kanban board for tracking.
- `hermes kanban create/list/complete/block` are the primary workflow tools.
- Do NOT treat task tracking as optional.

## Report Format

When presenting results:

```
做了什么：[action summary]
结果：[success/fail + key outcome]
```

No code blocks. No JSON. No command logs. No explanation of what you're about to do — just do it and report.

## Memory Persistence

User communication preferences are saved to BOTH memory and this skill. Memory captures "who the user is" (identity); this skill captures "how to communicate with this user" (procedure).

When the user corrects your style/format/language, update this skill immediately so future sessions don't repeat the mistake.

## Task Approach: Permission & Independence

This user has a clear operating principle for task handling:

1. **需要权限 → 直接开口** — If a task requires permissions/access the agent doesn't have (GitHub tokens, API keys, Discord bot tokens, admin privileges), tell the user what's needed. The user will provide it. Don't try workarounds, don't silently fail.

2. **不需要权限 → 自己想办法** — For everything that doesn't need user-granted access, find a reasonable solution independently. Research alternatives, use available tools, adapt patterns from similar tasks. Don't hand problems back to the user.

3. **禁止暴力方式** — Never use destructive/brute-force approaches (`rm -rf`, mass deletions, forced shutdowns, registry hacks, unsafe migration). If the only apparent solution is destructive, stop and explain why.

4. **卡住时说明原因** — If genuinely stuck (no available tool, no workable approach, environment limitation), state the blocker in one Chinese sentence. Don't keep trying the same failing approach, don't ask the user for step-by-step guidance.

When in doubt between "ask for help" and "find a way": think first — can this reasonably be solved with available tools? Yes → solve it. No → ask once.

## Workflow: 调研 → 汇报 → 批准 → 执行

This user explicitly requires a **research-first approach** for complex tasks:

1. **先调研** — 碰到不熟悉的技术问题，先去**源码 / GitHub / 官方文档**做深度调研。看源码实现、搜 issue 讨论、读官方设计文档，彻底搞懂底层原理。

2. **不能只靠自己推理** — 调研的核心是**读实际代码和文档**，不能凭 LLM 内部知识做推测。正确路径：找到对应源码文件 → 逐函数阅读 → 按调用顺序理清逻辑 → 整理完整分析。错误路径：凭经验先推测再找文档佐证。

   典型案例（本用户的纠正）：
   - ❌ 凭对 kanban 的理解推测 dispatch 逻辑，被纠正"你需要去学习一下不能只是自己推理"
   - ✅ 去读 `kanban_db.py::dispatch_once()`、`_default_spawn()`、`build_worker_context()` 源码 + KANBAN_GUIDANCE 系统 prompt + multi-agent-workflow 技能文档，才得到正确完整的工作流

3. **结构化汇报** — 调研结果按顺序整理，给出完整的分析框架（状态机、执行步骤顺序、函数调用链）。每个结论标注来源文件和行号。

4. **等批准** — 汇报后等用户批准，不擅自开干。用户说"批准后进行迭代"才动手。

5. **再执行** — 批准后按步骤执行，每步可复查。

### 适用场景

- 不熟悉的内部机制（看板调度、工具委派、配置系统、MCP 协议）
- 多步骤技术任务（桥接开发、集成测试、部署策略）
- 需要阅读源代码才能决策的任务
- 用户明确要求"去学习一下"的任何技术议题

### 禁止行为

- 不懂装懂，凭推测代替实际源码阅读
- 调研不充分就仓促动手 — 调研的标志是**实际读到了源码或文档**，不是"我觉得应该是这样"
- 跳过汇报阶段直接进入执行
- 先推理再找文档佐证（应该：先找文档再分析再汇报）

## 文件存储位置

**禁止在 C 盘存放任何工作文件、脚本、日志。** 所有文件放在 D 盘：

- 脚本 → `D:\hermes\scripts\`
- 日志 → `D:\hermes\scripts\proxy.log`（可配 PROXY_LOG）
- 代码项目 → `D:\projects\`
- 临时文件 → `D:\tmp\`

使用 MSYS 路径时注意：Python 把 `/d/...` 解析为 `C:\d\...`，必须用 `D:\...` 或 `D:/...`。