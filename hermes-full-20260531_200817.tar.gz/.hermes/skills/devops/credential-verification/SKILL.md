---
name: credential-verification
description: "Verify API tokens, credentials, and configuration files — env files, config files, API keys. Tests tokens against their respective services and reports results in plain text without exposing secret values."
trigger: User says they set a new token, updated env file, changed API key, or asks you to check/verify credentials.
---

# Credential & Configuration Verification

## Steps

1. **Identify the env/config file** — check modification timestamps (~/.hermes/.env, ~/.env, project .env) to find which was recently changed.
2. **List variable names only** — use `grep -oP '^[A-Za-z_][A-Za-z0-9_]*'` to extract key names. Do NOT output or log the values.
3. **Test each credential** — source the env file (e.g. `source ~/.hermes/.env`) and use the variable via shell expansion (`$VARIABLE_NAME`). Do NOT echo/cat/print the value.
   - GitHub token: `curl -s -H "Authorization: Bearer $TOKEN" https://api.github.com/user`
   - Discord bot token: `curl -s -H "Authorization: Bot $TOKEN" https://discord.com/api/v10/users/@me`
   - OpenAI-style API key: `curl -s -H "Authorization: Bearer $KEY" https://api.openai.com/v1/models`
4. **Present results in plain text** — describe what you tested and the result. Example format:

`GITHUB_TOKEN — ✅ 可用，以用户 xxx 身份认证成功`
`DISCORD_BOT_TOKEN — ✅ 可用，以机器人 xxx 身份认证成功`

## Pitfalls

- Never read/expose the token value. Only use shell variable expansion (`$VAR`).
- If `gh` CLI is not installed, use curl to test GitHub tokens directly.
- Some public API endpoints return 200 even without auth — verify the response body (username, bot name, etc.) to confirm real authentication.

## User Preferences (this user)

- **Report results conversationally**: Describe what you did and the outcome in simple text. Do NOT paste raw JSON, curl commands, or code snippets.
- **Plain-text summary only**: Use bullet points or short sentences. No code blocks, no command output dumps.
- **Verification without exposure**: Always use shell variable expansion, never echo/cat the token value.

## Verification checklist

- [ ] Token exists in the expected env file
- [ ] Token authenticates successfully against the relevant API
- [ ] Response body confirms identity (not just HTTP 200)
- [ ] Results reported in plain text without raw JSON/code
