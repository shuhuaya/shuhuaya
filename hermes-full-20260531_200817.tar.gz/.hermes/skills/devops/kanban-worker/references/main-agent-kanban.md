# 主 Agent 使用 Kanban 自我任务跟踪

## 何时使用

> ⚠️ 用户 **shuhua** 明确要求：**所有任务必须使用看板管理**（"任务时一定要使用看板功能"）。无论任务大小、是否单步，都要先建看板任务再执行。

当用户给你一个**多步骤、可跟踪、可并行**的任务时，应使用 kanban 看板来管理任务状态。典型信号：

- 用户说 "设置/配置/搭建 X"
- 任务包含 2 个以上子步骤
- 用户明确要求 "用看板"
- 步骤之间有依赖关系（先 A 后 B）
- 任务可能跨多个消息轮次

## 核心流程

```
1. hermes kanban list                 # 查看当前看板状态
2. hermes kanban create "标题"        # 创建新任务
3. 执行任务内容
4. hermes kanban complete <id>        # 标记完成（直接接 task_id 即可）
```

## 有效 CLI 命令速查

| 操作 | 命令 |
|------|------|
| 列出所有任务 | `hermes kanban list` |
| 创建任务 | `hermes kanban create "标题" [--initial-status running/blocked]` |
| 标记完成 | `hermes kanban complete <id>` （不需要 `--result`） |
| 阻塞 | `hermes kanban block <id> "阻塞原因"` |
| 解除阻塞 | `hermes kanban unblock <id>` |
| 编辑结果 | `hermes kanban edit <id> --result "新结果"` |
| 添加备注 | `hermes kanban comment <id> "备注内容"` |
| 查看任务详情 | `hermes kanban show <id>` |
| 查看任务日志 | `hermes kanban tail <id>` |
| 归档 | `hermes kanban archive <id>` |
| 排期 | `hermes kanban schedule <id>` |

## 任务状态图标

`hermes kanban list` 输出的状态符号：

| 图标 | 状态 | 含义 |
|------|------|------|
| ✓ | done | 已完成 |
| ◻ | todo | 待办 |
| ● | running | 执行中 |
| ⊘ | blocked | 阻塞（需用户介入） |
| ⏱ | scheduled | 已排期 |
| ▶ | ready | 就绪（待分配） |

## 陷阱

- **`complete` 不需要 `--result`** — `hermes kanban complete t_xxxx` 直接接 id 即可。部分 task_id 可能返回 `unknown id or terminal state`，需检查 id 或任务是否已归档。
- **没有 `move` 命令** — 不要尝试 `hermes kanban move <id> running`，会报错。状态流转由 `block`/`complete`/`unblock` 管理。
- **`edit` 必须带 `--result`** — `hermes kanban edit <id>` 不带参数会报错。
- **创建时不支持 `--assignee`** — `hermes kanban assign <id> --assignee <name>` 也会报错。
- **看板不加载用户偏好** — kanban 是纯任务状态管理，语言偏好/风格偏好仍需用 memory 或用户 profile 管理。

## 示例工作流

```bash
# 1. 查看当前状态
hermes kanban list

# 2. 创建任务
hermes kanban create "配置GitHub自动备份" --priority 1

# 3. 中途阻塞，等待用户输入
hermes kanban block t_xxxxxx "需要用户提供GitHub Token"

# 4. 用户提供后解除阻塞
hermes kanban unblock t_xxxxxx

# 5. 完成后标记
hermes kanban complete t_xxxxxx --result "备份脚本已配置，每天凌晨3点运行"
```

## 与 dispatched worker 的区别

| 方面 | 主 Agent（你） | Dispatched Worker |
|------|---------------|-------------------|
| 运行环境 | 实时对话 | 后台进程 |
| Kanban API | `hermes kanban` CLI | `kanban_*` 内置工具 |
| 用户交互 | 可以问问题（clarify） | 只能 `kanban_block` 等用户解阻塞 |
| 适用场景 | 跟踪当前对话中的任务 | 异步多 agent 协作 |
