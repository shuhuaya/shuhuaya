---
name: windows-desktop-launch
description: Launch Windows GUI applications from the agent so they appear on the user's interactive desktop (Console session), not as background/service processes the user can't see.
trigger:
  - User says "打开" / "打开到桌面" / "帮我打开 XXX" for a Windows GUI app
  - User asks you to launch a desktop application they should see
  - Previous launch attempt via terminal(background=true) didn't show a visible window
tags: [windows, gui, desktop, interactive, scheduled-task, powershell]
---

# Windows Desktop GUI Launch

## Problem

When you launch a Windows GUI application via `terminal(background=true)` or even `cmd.exe /c start`, the process may run but its window does **not** appear on the user's interactive desktop. The process shows up in Task Manager under the "Services" session, not "Console".

This is because git-bash / Hermes terminal runs in a session context that may not have interactive desktop station access.

## Solution: PowerShell Scheduled Task

The reliable way to launch a GUI app visible on the interactive desktop is to create and immediately execute a scheduled task via PowerShell.

### Method 1: Full Scheduled Task (most reliable)

```powershell
$action = New-ScheduledTaskAction -Execute 'C:\Path\To\App.exe'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)
Register-ScheduledTask -TaskName 'TempAppLaunch' -Action $action -Trigger $trigger -User 'Administrator' -RunLevel Highest -Force
Start-ScheduledTask -TaskName 'TempAppLaunch'
```

**Important**: Use single quotes for paths in PowerShell to avoid git-bash escape issues with backslashes.

### Method 2: Protocol URL (for apps that support it)

Some apps support custom protocol URLs. Find the correct scheme via the registry:

```bash
cmd.exe //c "reg query HKCR\ /s /f orpheus | findstr HKEY"    # Search for known schemes
cmd.exe //c "reg query HKCR\orpheus\shell\open\command /ve"    # Check exact command template
```

Launch with:

```powershell
Start-Process 'scheme://path'
```

Or combine with a scheduled task if needed.

### Method 3: Direct argument from file association

Discover CLI arguments from file associations (often reveals --play, --webcmd, etc.):

```bash
cmd.exe //c "assoc .ncm"       # → .ncm=cloudmusic.ncm
cmd.exe //c "ftype cloudmusic.ncm"  # → command template with args
```

The template reveals the executable path and accepted flags. Note: the registry value may have **NO SPACE** between the executable and its argument (e.g., `cloudmusic.exe"--webcmd="%1"`). When constructing the command yourself, pass the argument normally — the OS's ShellExecute handles the spacing correctly via `Start-Process -ArgumentList`.

## Verification

Check that the process is running under the Console session:

```bash
tasklist | grep -i <appname>
```

Look for "Console" in the session column instead of "Services".

## Cleanup

Remove the scheduled task after launching:

```powershell
Unregister-ScheduledTask -TaskName 'TempAppLaunch' -Confirm:$false
```

Or via schtasks (watch git-bash backslash escaping):
```
schtasks /delete /tn "TempAppLaunch" /f
```
Note: git-bash interprets `\d` and `\t` as escape sequences. Use the PowerShell command above instead.

## Pitfalls

- **Git-Bash backslash escaping**: Commands like `schtasks /delete /tn "Name" /f` fail because git-bash interprets `\\d`, `\\t`, `\\f` as escapes. Use PowerShell where possible.
- **cmd.exe /c start** may still launch in non-interactive session — verify with `tasklist`.
- **background=true** without proper session handling will NOT show a window to the user.
- **PowerShell `Start-Process` alone** (without Scheduled Task) may silently launch in Service session, not Console — check the session column from `tasklist`.
- **Protocol URL handlers may not use the expected scheme** — always verify the actual registered protocol in the registry:
  
  ```bash
  cmd.exe //c "reg query HKCR\ /s /f orpheus | findstr HKEY"    # Find registered schemes
  cmd.exe //c "reg query HKCR\orpheus\shell\open\command /ve"    # Check command template
  ```

- **Discover CLI arguments from file associations** — When you don't know what CLI args an app accepts, check its registered file association via `cmd.exe //c "ftype <progid>"` (the ProgID from `assoc .ext`). The command template there reveals the executable path and flags (e.g., `--play="%1"` for cloudmusic).

- **GitHub AI automation projects for Windows desktop control** — Several open-source projects provide AI-agent-friendly interfaces:

  - **RavaniRoshan/winscript-mcp** (8★): AppleScript-for-Windows MCP server, 59 tools (UIA, COM, OCR, Win32). Install: `pip install winscript`, then add to `~/.hermes/config.yaml` under `mcp_servers`.
  - **aloth/PowerSkills** (25★): PowerShell automation toolkit for AI agents
  - **AmrDab/clawdcursor** (338★): MCP-powered GUI automation fallback layer
  - **NickRomanek/clawbridge** (19★): Open-source browser & desktop automation agent
  - **skalesapp/skales** (1082★): Local-first AI desktop agent (standalone)
  - **appergb/desktop-agent-ops** (15★): Cross-platform GUI automation skill

- **pywinauto in scheduled tasks for UI automation** — When protocol URLs and CLI arguments aren't enough, use **pywinauto** inside a scheduled task:

  ```python
  # control_app.py — run via scheduled task on interactive desktop
  import time, pywinauto
  from pywinauto import Desktop
  from pywinauto.keyboard import send_keys
  desktop = Desktop(backend='uia')
  for w in desktop.windows():
      if 'target' in w.window_text().lower():
          w.set_focus()
          time.sleep(0.5)
          send_keys('^k'); time.sleep(0.5)
          send_keys('search text'); time.sleep(0.5)
          send_keys('{ENTER}')
          break
  ```

  Pass via scheduled task:
  ```powershell
  $action = New-ScheduledTaskAction -Execute 'python3' `
    -Argument 'C:\path\to\control_app.py'
  $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds(5)
  Register-ScheduledTask -TaskName 'ControlApp' -Action $action -Trigger $trigger `
    -User 'Administrator' -RunLevel Highest -Force
  Start-ScheduledTask -TaskName 'ControlApp'
  ```

  **Session isolation**: Hermes terminal runs in Session 0 (Services), interactive desktop is Session 1. pywinauto's `Desktop()` cannot see Session 0 windows. Running via scheduled task with `-User 'Administrator'` places it in Session 1.

- **Hermes browser analysis**: See `references/hermes-browser-analysis.md` for details on Headless Chromium 148, protocol URL triggering limitations, and session context.

- **Protocol URL discovery via DLL binary analysis**: When protocol URLs don't work and you need to find the exact URL format an app accepts, extract strings from its main DLL:
  
  ```bash
  python3 -c "
  import re
  with open('C:/Program Files/App/app.dll', 'rb') as f:
      data = f.read()
  text = data.decode('utf-8', errors='ignore')
  matches = re.findall(r'scheme://[a-zA-Z0-9/?&=_:.]+', text)
  for m in sorted(set(matches)):
      print(m)
  "
  ```
  
  This finds embedded URL patterns like `orpheus://native/start.html`, `orpheus://native/lrc`, `orpheus://cache/?`, etc. Also search for parameter names like `songId`, `songid` to guess query params.
  
- **Single-instance apps forward via IPC**: Many apps (NetEase CloudMusic, QQ Music) are single-instance. When you launch a second instance with a protocol URL, the new process forwards the command to the existing instance via IPC (named pipe, socket) and exits immediately. No new process appears in `tasklist`. Check by looking for memory/network changes in the existing Console process, or just ask the user if the app responded.

- **`file://` URLs block external resource fetches** — browsers enforce CORS on `file://` origins. When creating a custom HTML page that loads external audio/video, always serve it via HTTP (e.g., `python3 -m http.server` on localhost) instead of using `file://`. `file://` origins cannot make fetch/XHR requests to `http://` or `https://` targets, and `<audio>/<video>` src attributes may silently fail.
- The scheduled task's `-Once -At (Get-Date).AddMinutes(1)` sets a trigger 1 minute out; calling `Start-ScheduledTask` immediately overrides this.
- **`references/hermes-browser-analysis.md`** — Headless Chromium 148 browser analysis for protocol URL triggering limitations and session context.
- **`references/netease-cloud-music.md`** — NetEase Cloud Music desktop launch example (protocol URLs, scheduled tasks, DLL binary analysis, web player fallbacks).
- **`references/voice-transcription-windows.md`** — Voice message transcription on Windows (install ffmpeg via chocolatey, faster-whisper setup, transcribing .ogg Opus audio from Discord/Telegram).

## Steps

1. Find the interactive session ID: `quser` or `query session` (look for "console" session)
2. Create a PowerShell scheduled task (Method 1) targeting the installed EXE path
3. Execute `Start-ScheduledTask` immediately
4. Verify with `tasklist | grep <appname>` — check for "Console" in session column
5. Clean up the scheduled task
6. Optionally send a protocol URL (Method 2) if the app supports deep linking
