# Windows 语音消息转录指南

## 问题

用户通过 Discord/Telegram 等平台发送语音消息（通常是 `.ogg` Opus 格式），但 Hermes 的 STT 系统无法转录，因为缺少 ffmpeg。

## 解决方案

### 第一步：安装 ffmpeg

通过 Chocolatey 安装（ffmpeg 会自动装到 `C:\ProgramData\chocolatey\bin\`，但可能不在 git-bash 的 PATH 中）：

```bash
choco install ffmpeg -y
```

安装后的路径：`/c/ProgramData/chocolatey/bin/ffmpeg.exe`

### 第二步：转码为 WAV

```bash
"/c/ProgramData/chocolatey/bin/ffmpeg.exe" -i input.ogg output.wav
```

### 第三步：安装 faster-whisper（在 Hermes 虚拟环境中）

```bash
cd /d/hermes/hermes-agent && source venv/Scripts/activate && pip install faster-whisper
```

### 第四步：转录

```python
from faster_whisper import WhisperModel
model = WhisperModel('base', device='cpu', compute_type='int8')
segments, info = model.transcribe('audio.wav', language='zh')
for seg in segments:
    print(f'[{seg.start:.1f}s - {seg.end:.1f}s] {seg.text}')
```

## 注意事项

- `base` 模型约 150MB，首次运行会自动下载到 `~/.cache/huggingface/`
- 长音频建议使用 `large-v3` 模型以获得更高准确率，但首次下载约 3GB
- 中文语音用 `language='zh'` 指定语言，可以提高准确率
- 如果下载慢，可以设置 `HF_TOKEN` 环境变量（HuggingFace Token）来加速

## 常见语音来源

| 平台 | 格式 | 采样率 |
|------|------|--------|
| Discord | OGG Opus | 48kHz, mono |
| Telegram | OGG Opus | 48kHz, mono |
| WhatsApp | OGG Opus | 16kHz, mono |

## 音频缓存位置

语音消息会自动保存到 `~/.hermes/audio_cache/` 目录下，文件名类似 `audio_<hash>.ogg`。
