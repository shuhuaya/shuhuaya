# NetEase Cloud Music — Desktop Launch Example

**Install path**: `C:\Program Files\NetEase\CloudMusic\cloudmusic.exe`  
**Protocol scheme**: `orpheus://` (NOT `cloudmusic://` — check `HKCR\orpheus`)
**Protocol command**: `"C:\Program Files\NetEase\CloudMusic\cloudmusic.exe"--webcmd="%1"` (NO space between `.exe"` and `--webcmd=`)
**Song ID format**: `orpheus://song?id=<numeric_id>`
**Internal URL patterns found in cloudmusic.dll**:
- `orpheus://native/start.html` — play/start endpoint
- `orpheus://native/lrc` — lyrics
- `orpheus://native` — base native command
- `orpheus://cache/?` — cache

## Launch to interactive desktop

```powershell
$action = New-ScheduledTaskAction -Execute 'C:\Program Files\NetEase\CloudMusic\cloudmusic.exe'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)
Register-ScheduledTask -TaskName 'NetEaseDesktop' -Action $action -Trigger $trigger -User 'Administrator' -RunLevel Highest -Force
Start-ScheduledTask -TaskName 'NetEaseDesktop'
```

## Play a specific song via protocol URL

```powershell
Start-Process 'orpheus://song?id=<song_id>'
```

Or via command-line with `--webcmd` argument (no space between exe and --webcmd):

```powershell
Start-Process -FilePath 'C:\Program Files\NetEase\CloudMusic\cloudmusic.exe' `
  -ArgumentList '--webcmd=orpheus://song?id=<song_id>'
```

**⚠️ Caveat**: The client is single-instance. The new process forwards the command to the existing running instance via IPC and exits immediately. No new process appears in `tasklist`. The song should appear in the running client.

**⚠️ Verify registration**: The `orpheus://` protocol is registered under `HKCR\orpheus`. Check with:
```bash
cmd.exe //c "reg query HKCR\orpheus\shell\open\command /ve"
```
Expected value: `"C:\Program Files\NetEase\CloudMusic\cloudmusic.exe"--webcmd="%1"`

**⚠️ Protocol registration format**: The registry has NO SPACE between `.exe"` and `--webcmd=`. When using `Start-Process -ArgumentList`, pass `--webcmd=...` normally (without the extra quote wrapping) — PowerShell handles the spacing.

### Alternative: Use the web page's button

Navigate to the song page, then click the "去客户端播放" link. With the `orpheus://` protocol registered, this triggers the client:

```
browser_navigate "https://music.163.com/#/song?id=<song_id>"
browser_click ref=e9       # "去客户端播放" button in bottom bar
```

## Fallback: Direct MP3 playback in browser (no login required)

When the protocol URL doesn't work, use the direct MP3 URL:

```
https://music.163.com/song/media/outer/url?id=<song_id>.mp3
```

Opening this in the browser plays the song directly via an HTML5 `<video>` element. The URL auto-redirects to the CDN MP3 on `m701.music.126.net`.

## Find song by API (no login required)

```bash
curl -s "https://music.163.com/api/search/get?s=<song_name_encoded>&type=1&offset=0&total=true&limit=1" \
  -H "Referer: https://music.163.com/"
```

Returns JSON with song ID, artist, album info. Parse the `result.songs[0].id` field.

| Parameter | Meaning |
|-----------|---------|
| `s` | Search query (URL-encoded) |
| `type=1` | Song search (1=song, 10=album, 100=artist, 1000=playlist) |
| `offset` | Pagination offset |
| `limit` | Results per page |
| `total=true` | Include total count in response |

**Response example**:
```json
{
  "result": {
    "songs": [{
      "id": 1875941511,
      "name": "假面舞会",
      "artists": [{"name": "很美味", "id": 12358435}],
      "album": {"name": "假面舞会", "id": 132838314}
    }],
    "songCount": 330,
    "hasMore": true
  },
  "code": 200
}
```

## Discover protocol URLs via DLL binary analysis

When the documented protocol URL format doesn't work, extract URL patterns from the main DLL:

```bash
python3 -c "
import re
with open('C:/Program Files/NetEase/CloudMusic/cloudmusic.dll', 'rb') as f:
    data = f.read()
text = data.decode('utf-8', errors='ignore')
# Find all orpheus URL patterns
matches = re.findall(r'orpheus://[a-zA-Z0-9/?&=_:.]+', text)
for m in sorted(set(matches)):
    print(m)
# Also search for parameter names
params = re.findall(r'song[iI]d|song[iI]ds', text)
for p in sorted(set(params)):
    print('Param:', p)
"
```

Known patterns from `cloudmusic.dll`:
- `orpheus://native/start.html` — start/play endpoint (likely accepts `?songId=` parameter)
- `orpheus://native/lrc` — lyrics endpoint
- `orpheus://native` — base native command
- `orpheus://cache/?` — cache endpoint

The file extension `.html` is just a routing convention; it's not a real HTML file.

### Web player alternative: "去客户端播放" button behavior

The "去客户端播放" button on `music.163.com` uses:
```html
<a href="javascript:;" data-action="orpheus" class="btn" title="去客户端播放">去客户端播放</a>
```

The `data-action="orpheus"` attribute signals JavaScript to dynamically construct and trigger the `orpheus://` URL based on current page state (song ID, album ID, etc.). The actual `orpheus://` URL is NOT embedded in the HTML — it's built at runtime by the page's JavaScript.

If clicking this button from the browser doesn't trigger playback:
1. The `orpheus://` protocol might not be registered (`cmd.exe //c "reg query HKCR\orpheus\shell\open\command /ve"`)
2. The headless Chromium browser might block custom protocol URLs from programmatic triggers
3. Use the Scheduled Task approach (above) as a fallback

### "点击打开客户端" inside iframe

Inside the song page iframe, there's a "点击打开客户端" StaticText element. This is a separate UI element from the bottom-bar "去客户端播放" button, but both trigger the same `orpheus://` protocol mechanism.

### Web player alternative (no client needed)

For instant playback without relying on the client at all:
```bash
# Open directly in browser via the song's streaming MP3 URL
# The browser navigates to the CDN and shows a <video> player
browser_navigate "https://music.163.com/song/media/outer/url?id=<song_id>.mp3"
```

**⚠️ Caveat**: The direct MP3 URL plays in the browser's built-in `<video>` element, but the page may become empty after the download finishes. For continuous playback, use the HTML audio player below.

### Stable fallback: HTML audio player via local HTTP server

When the direct MP3 URL playback is unreliable, create a self-contained HTML page with an `<audio>` element and serve it via a local HTTP server (CORS blocks `file://` origin from fetching external audio).

Steps:
1. Write an HTML player file with `<audio controls autoplay>` sourcing the MP3 URL
2. Start a local Python HTTP server: `python3 -m http.server 8888 --directory "/c/path/to/dir"`
3. Open via browser: `browser_navigate "http://localhost:8888/player.html"`
4. Click the play button manually — browser autoplay policy usually blocks auto-play on first load

**Why not `file://`?** Browsers block fetch/XHR from file:// origins. Use HTTP.

Verification: snapshot shows `Audio` element with button text changing from "播放" to "暂停" and time slider advancing.

## Fallback: Download MP3 + play via `--play=` argument

When the `orpheus://` protocol is NOT registered, download the song as MP3 and pass it to `cloudmusic.exe` via the `--play=` argument.

### 1. Find the `--play=` flag from file association

Check how `.ncm` files are opened:

```bash
cmd.exe //c "assoc .ncm"       # → .ncm=cloudmusic.ncm
cmd.exe //c "ftype cloudmusic.ncm"  # → cloudmusic.ncm="C:\Program Files\NetEase\CloudMusic\cloudmusic.exe"--play="%1"
```

This confirms `cloudmusic.exe` accepts `--play=<filepath>`.

### 2. Download the song as MP3

```bash
curl -sL -o "/c/Users/<user>/song.mp3" \
  "https://music.163.com/song/media/outer/url?id=<song_id>" \
  -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
  --max-time 30
```

The URL redirects to the actual CDN MP3. The `-L` flag follows the redirect.

### 3. Play with cloudmusic.exe via scheduled task

```powershell
$action = New-ScheduledTaskAction -Execute 'C:\Program Files\NetEase\CloudMusic\cloudmusic.exe' `
  -Argument '--play=C:\Users\Administrator\song.mp3'
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1)
Register-ScheduledTask -TaskName 'NetEasePlay' -Action $action -Trigger $trigger -User 'Administrator' -RunLevel Highest -Force
Start-ScheduledTask -TaskName 'NetEasePlay'
```

If the client is already running on the interactive desktop, use:

```powershell
Start-Process -FilePath 'C:\Program Files\NetEase\CloudMusic\cloudmusic.exe' `
  -ArgumentList '--play=C:\Users\Administrator\song.mp3'
```

**Verify**: `tasklist | grep cloudmusic` — look for "Console" in session column (not "Services").

### 4. Cleanup task + temp file

```powershell
Unregister-ScheduledTask -TaskName 'NetEasePlay' -Confirm:$false
Remove-Item 'C:\Users\Administrator\song.mp3'
```

## Cleanup (general)

```powershell
Unregister-ScheduledTask -TaskName 'NetEaseDesktop' -Confirm:$false
```
