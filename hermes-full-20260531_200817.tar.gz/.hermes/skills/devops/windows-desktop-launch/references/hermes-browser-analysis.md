# Hermes Browser Analysis

## Browser identity

- **Engine**: Headless Chromium 148 (`HeadlessChrome/148.0.0.0`)
- **OS**: Windows NT 10.0 (Win64)
- **Stealth**: `["local"]` — runs locally on the host machine, NOT via Browserbase residential proxies
- **Stealth warning**: Bot detection may be more aggressive without residential proxy support

## Architecture

Hermes' browser tools (`browser_navigate`, `browser_click`, `browser_snapshot`, `browser_console`, etc.) use a Playwright/Puppeteer-managed Chromium instance running headless on the local machine.

## Key capabilities

| Capability | Supported | Notes |
|------------|-----------|-------|
| JavaScript execution | ✅ | via `browser_console(expression=...)` |
| HTML5 audio/video | ✅ | `<audio>`, `<video>` elements work |
| Custom protocol URLs | ⚠️ | Headless Chromium may block `orpheus://` style protocols from programmatic triggers. Real user clicks (`browser_click`) have higher success rate |
| File:// URLs | ⚠️ | Works for navigation but CORS blocks fetch/XHR to external origins |
| iframe cross-origin access | ❌ | Cannot access iframe.contentDocument for cross-origin frames |
| CDP (Chrome DevTools Protocol) | ❌ | Not directly exposed via current tools |
| Console log capture | ✅ | Returns `console_messages` array with log/warn/error entries |
| Page eval return | ✅ | Expression return value serialized as result |

## Protocol URL triggering (critical limitation)

When you need to trigger a custom protocol handler (e.g., `orpheus://`, `spotify://`, `steam://`) from a headless Chromium instance:

1. **Direct navigation** (`browser_navigate(url=...)`): Fails with `net::ERR_NAME_NOT_RESOLVED` for custom schemes
2. **JavaScript `location.href=`**: May navigate the page to `about:blank` without triggering the handler
3. **JS `document.createElement('a').click()`**: Usually blocked — headless Chrome requires a real user gesture
4. **`browser_click` on an `<a href="scheme://...">` link**: Most likely to succeed if the protocol handler is registered in the OS and the browser is not running in a sandboxed context
5. **Scheduled task (most reliable)**: Fall back to starting the app via PowerShell scheduled task (see main SKILL.md)

## Session context

The Hermes agent process (and therefore the browser) runs in Session 0 (Services session) on Windows. Interactive desktop apps run in Session 1 (Console session). This means:
- The browser CAN access web pages and run JavaScript
- The browser CANNOT interact with windows in Session 1 via OS APIs
- Custom protocol handlers triggered from the browser may or may not reach Session 1 depending on how the handler is registered

## NetEase Cloud Music specific findings

- The "去客户端播放" button on `music.163.com` uses:
  ```html
  <a href="javascript:;" data-action="orpheus" class="btn" title="去客户端播放">去客户端播放</a>
  ```
- The `data-action="orpheus"` attribute signals JavaScript to construct and trigger the `orpheus://` URL dynamically
- The actual `orpheus://` URL is NOT directly embedded in the HTML — it's built by JavaScript based on the current page state (song ID, album ID, etc.)
