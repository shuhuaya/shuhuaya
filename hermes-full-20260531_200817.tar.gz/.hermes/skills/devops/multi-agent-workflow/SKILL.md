---
name: multi-agent-workflow
description: 多智能体并行工作流模板 — 在 Kanban 看板上编排多个 agent 并行工作、定义任务依赖关系、设置质量门控（自检+审核+修复循环+组织替换）。
version: 2.0.0
author: Hermes Agent
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [kanban, multi-agent, workflow, orchestration, parallel]
    related_skills: [kanban-worker, kanban-orchestrator, hermes-agent]
---

# 多智能体并行工作流模板

> 基于 Hermes Agent Kanban 看板系统（v0.13+）编排多智能体并行协作。

加载此技能后，详见 `references/multi-agent-workflow-reference.md` 参考文件获取完整的 4 种工作流模式、profile 分配策略、黑板通信、以及常用示例。

`references/quality-gated-pipeline.md` 包含质量门控流水线（自检+审核+修复循环+组织替换）的完整契约格式和协调层操作流程。

## ⚠️ 工作流设计纪律

设计 kanban 工作流时，必须先查阅官方源码和文档，不能单靠推理拼凑。本技能引用的所有状态机和调度机制均来自 `hermes_cli/kanban_db.py` 和 `gateway/run.py` 的源码验证。

## 用户偏好

用户要求极端简洁，只接受中文交流，不接受代码块/JSON/原始输出堆积。所有看板操作结果用纯文本描述即可。用户只收最终完成回执，不在内部循环中打扰用户。

## 快速开始

### 1. 自动分解（推荐）

把大目标丢到 triage，让调度器自动分解：

```bash
hermes kanban create "构建电商网站" --assignee planner --triage
```

调度器在下一次 tick 中自动将任务分解为并行子任务图。

### 2. 手动编排（固定流程）

```python
# orchestrator 或 root worker 中调用
root = kanban_create(title="项目X", assignee="default")

# 并行扇出
t1 = kanban_create(title="模块A", assignee="profile-a", parents=[root["task_id"]])
t2 = kanban_create(title="模块B", assignee="profile-b", parents=[root["task_id"]])

# 汇合（依赖所有并行任务完成）
synth = kanban_create(
    title="汇总",
    assignee="default",
    parents=[t1["task_id"], t2["task_id"]]
)

# 完成后声明
kanban_complete(
    summary="创建了并行工作流：A + B → 汇总",
    created_cards=[t1["task_id"], t2["task_id"], synth["task_id"]]
)
```

### 3. Swarm 拓扑

```bash
hermes kanban swarm "部署微服务" --workers 3
# 自动生成: 并行 worker → verifier → synthesizer
```

## 四种工作流模式

| 模式 | 适用场景 | 特点 |
|------|---------|------|
| 并行扇出 | 独立子任务并行 | 全部完成 → 汇合 |
| 流水线 | 顺序执行 | 前一阶段输出 → 下一阶段输入 |
| DAG | 交错依赖 | 复杂依赖图，自动晋升（todo→ready） |
| Swarm | 多路并行+验证+综合 | 内建命令 `hermes kanban swarm` |

## Profile 分配建议

| Profile | 用途 |
|---------|------|
| `default` | 通用/汇总/综合 |
| `frontend-engineer` | 前端开发 |
| `backend-engineer` | 后端开发 |
| `code-reviewer` | 代码审查 |
| `researcher` | 研究分析 |
| `writer` | 文档编写 |
| `tester` | 测试 |
| `devops` | 部署运维 |
| `planner` | 分解规划 |

## 黑板通信

并行 worker 之间通过根任务的评论交换结构化信息：

```python
# worker 写入
kanban_comment(
    task_id=root_id,
    body=json.dumps({"module": "auth", "status": "done", "endpoints": ["/login"]})
)

# synthesizer 读取
root = kanban_show(task_id=root_id)
# root.comments 包含所有 worker 的产出
```

## 注意事项

- 捕获所有 `kanban_create()` 返回值，下游依赖需要真实 task_id
- 超过 1 小时的任务需定期 `kanban_heartbeat()` 防止被回收
- 用 `parents=[]` 在创建时声明依赖比事后 `kanban_link()` 更干净
- 不要在 worker 中调用 `clarify` — 使用 `kanban_block(reason=...)`
- 完成时用 `created_cards=[]` 列明创建的子任务（防幻觉门错误）
- Worker 退出前必须调用 `kanban_complete()` 或 `kanban_block()`（防协议违规）

[Skill directory: C:\Users\Administrator\.hermes\skills\devops\multi-agent-workflow]
Resolve any relative paths in this skill (e.g. `scripts/foo.js`, `templates/config.yaml`) against that directory, then run them with the terminal tool using the absolute path.
