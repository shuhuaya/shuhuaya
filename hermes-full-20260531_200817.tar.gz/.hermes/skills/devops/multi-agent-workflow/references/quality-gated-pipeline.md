# 质量门控流水线 — T-R 对契约与协调规程

> 基于 Kanban 看板的多 agent 质量控制体系。
> 版本 2.0.0 | 适用条件：single profile (default)，手动 dispatch

---

## 一、角色定义

| 角色 | 类型 worker | 职责 | 完成方式 |
|------|-------------|------|---------|
| **T** (团队/组织) | 实现者 | 干活 + 自检 | `kanban_complete`（自检通过才交） |
| **R** (审查) | 审查者 | 审核 T 产出 | `kanban_complete`（通过）或 `kanban_block`（失败） |
| **FIX** (返工) | 修复者 | 修 R 指出的问题 | `kanban_complete` |
| **协调层** | 主 agent | 监控流转、处理循环、做组织替换 | `hermes kanban` CLI |

---

## 二、T Worker 自检纪律

### 内部循环

```
T: running
  ├─ 干活（写代码/配置/脚本）
  ├─ 自检
  │    ├─ 全部通过 → kanban_complete（带 metadata）
  │    └─ 有失败 → 继续修，不自检通过不 complete
```

### 自检清单（T 的 body 中的 Acceptance Criteria）

T 的 `--body` 必须包含 `## Acceptance Criteria` 逐条可验证项：

```markdown
## Acceptance Criteria
- [ ] 服务监听 :8899 端口
- [ ] curl 请求返回 200
- [ ] 错误日志输出到文件
- [ ] 无核心功能遗漏
```

### complete metadata 产出格式

工具 worker（T）使用 Python `kanban_complete` 工具；我（主 agent）使用 CLI 创建时无需 metadata，等 worker 自己 complete。

```python
kanban_complete(
    summary="实现X，监听8899端口，直连通",
    metadata={
        "changed_files": ["D:/codex_bridge.py"],
        "self_check": {
            "tests_passed": 16,
            "tests_run": 16,
            "functional_test": "curl :8899/v1/models → 200 OK",
        },
        "criteria_met": ["监听端口", "转发请求", "错误处理"],
        "risks": ["SSE参数待调"],
        "decisions": ["选了http.server减少依赖"],
    }
)
```

**metadata 是 R worker 的审查依据**，必须完整、真实。

---

## 三、R Worker 审核标准

### 审核流程

```
R: running
  ├─ kanban_show() → 读 parent T 的 metadata
  ├─ 逐项审核
  │    ├─ 文件存在？所有 changed_files 路径有效
  │    ├─ 自检结果可信？覆盖了所有 AC
  │    ├─ 实际验证？运行测试/curl/编译
  │    └─ 风险可接受？
  ├── 全通过 → kanban_complete() → 下游晋升
  └── 有问题 → kanban_block(reason="review-fail: 序号. 问题")
```

### Block reason 格式

审核失败时，block reason 以 `review-fail:` 开头，每行一个具体问题：

```
review-fail: 1. 端口8899实际未绑定
             2. 缺少连接超时处理
             3. 无日志输出
```

**问题要具体、可执行**，不能模糊。协调层解析这个格式来创建 FIX 任务。

---

## 四、修复循环（协调层）

当 R worker 因 `review-fail` block 时，协调层（我）执行以下规程：

```bash
# 1. 读问题
hermes kanban show <R_ID>
# 从 block reason 解析出每个问题

# 2. 创建修复任务（无 parent，直接 ready）
FIX_ID=$(hermes kanban create "FIX-<T名>: <问题摘要>" --assignee default --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

# 3. 创建再审任务（依赖 FIX 完成）
R_RETRY_ID=$(hermes kanban create "R-<T名>-v2: 再审" --assignee default --parent "$FIX_ID" --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

# 4. reclaim 原审查任务（释放状态不卡住）
hermes kanban reclaim <R_ID>

# 5. 推进
hermes kanban dispatch   # FIX worker 启动 → 修
# FIX complete → R-RETRY 自动 ready
hermes kanban dispatch   # R-RETRY 启动 → 再审
```

### 循环收敛保证

连续 2 次 `review-fail` → 触发**组织替换**（见第五节）。这是 `config.yaml` 中 `kanban.failure_limit: 2` 的硬边界，超过后 task 自动进入 `blocked` 状态。

---

## 五、组织替换（Organization Replacement）

当同一实现任务连续 2 次审查失败，原组织（T task）被判定为不合格，执行替换：

```bash
# 1. 归档旧组织及其相关任务
hermes kanban archive <T_ID>          # 实现组织
hermes kanban archive <R_ID>          # 审查组织
hermes kanban archive <FIX_ID>        # 修复任务（如果有）
hermes kanban archive <R_RETRY_ID>    # 再审任务（如果有）

# 2. 创建新组织（用不同策略）
T_V2_ID=$(hermes kanban create "<T名>-v2: 重新实现" \
  --assignee default \
  --body "不同于上次的策略..." \
  --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

R_V2_ID=$(hermes kanban create "R-<T名>-v2: 审查新实现" \
  --assignee default \
  --parent "$T_V2_ID" \
  --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

# 3. 修复依赖链：原下游现在依赖 R_V2
hermes kanban link parent="$R_V2_ID" child="<下游_ID>"

# 4. 新组织上岗
hermes kanban dispatch
```

### 每次替换的策略差异化

| 维度 | 原组织 | 新组织 v2 |
|------|--------|-----------|
| 实现方案 | 换技术栈（如 http.server → fastapi） |
| 任务 body | 强化约束，写清楚上轮踩过的坑 |
| skill | `--skill <针对性的技能>` |
| model | 可用 `--model-override` 换模型 |

### 三次全失败上报

连续 3 次组织更迭（T→T-v2→T-v3）仍失败 → 任务 auto-block，协调层上报用户：
> "该任务经 3 轮组织更迭无法自动完成，需要人工介入判断是否继续。"

---

## 六、树状依赖链完整示例

```bash
# === Phase 1: 建树 ===

# 叶子实现任务（无依赖）
T1_ID=$(hermes kanban create "T1: 实现桥接脚本" --assignee default --body "
## Goal
实现 Codex ↔ OpenCode Go 桥接服务

## Acceptance Criteria
- [ ] 监听 :8899 端口
- [ ] 支持 Responses API 格式
- [ ] 错误日志到文件
" --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

R1_ID=$(hermes kanban create "R1: 审查桥接脚本" --assignee default --parent "$T1_ID" --body "
审查 T1 产出：
1. 所有文件存在且功能正常
2. AC 全部满足
3. 通过 → complete / 不通过 → block(review-fail)
" --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

T2_ID=$(hermes kanban create "T2: SSE流式改造" --assignee default --body "
## Goal
在桥接服务上增加 SSE 流式支持
" --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

R2_ID=$(hermes kanban create "R2: 审查SSE" --assignee default --parent "$T2_ID" --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

# 汇合任务（依赖 R1 和 R2 都通过）
T3_ID=$(hermes kanban create "T3: 集成验证" --assignee default --parent "$R1_ID" --parent "$R2_ID" --body "
## Goal
端到端验证：Codex → 桥接 → OpenCode Go 全链路
" --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

R3_ID=$(hermes kanban create "R3: 最终验收" --assignee default --parent "$T3_ID" --json | python -c "import sys,json;print(json.load(sys.stdin)['task_id'])")

# === Phase 2: 驱动 ===
# 主 agent 每步只 dispatch + 读结果 + 处理异常
hermes kanban dispatch    # T1 running → complete → R1 ready
hermes kanban dispatch    # R1 running
                          # ├─ PASS → complete → T2 ready
                          # └─ FAIL → block → 协调层创建 FIX+R-v2 → dispatch
hermes kanban dispatch    # T2 running → complete → R2 ready
hermes kanban dispatch    # R2 running → ...
  ...                     # 一路推进直到 R3 complete

# === Phase 3: 最终 ===
echo "最终完成"
```

---

## 七、协调层（主 agent）操作清单

| 步骤 | 操作 | 说明 |
|------|------|------|
| 1 | `hermes kanban create ...` | 一次性建完整依赖树 |
| 2 | `hermes kanban dispatch` | 驱动第一个 ready task |
| 3 | `hermes kanban list` | 检查当前各 task 状态 |
| 4 | `hermes kanban show <id>` | 查看具体任务详情/评论 |
| 5 | `hermes kanban log <id>` | 查看 worker 完整日志 |
| 6 | `hermes kanban reclaim <id>` | 回收卡住/running 的有问题 task |
| 7 | `hermes kanban link parent child` | 修复依赖链（替换组织时） |
| 8 | `hermes kanban archive <id>` | 归档过期/替换掉的 task |

**不作为：**
- ❌ 不手动审查 T 产出（那是 R worker 的事）
- ❌ 不介入正常流转（依赖链自动晋升）
- ❌ 不打扰用户（只在最终完成时汇报；只在上报3次替换失败时找用户）
