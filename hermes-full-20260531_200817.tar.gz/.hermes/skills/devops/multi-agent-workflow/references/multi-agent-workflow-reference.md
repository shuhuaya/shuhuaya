# 多智能体并行工作流模板 — 完整参考

> 基于 Hermes Agent Kanban 看板系统（v0.13+）的多智能体协作模式。
> 版本 1.0.0 | 用途：在 Kanban 看板上编排多个智能体并行工作

---

## 一、核心概念

在看板系统中实现多智能体并行，依赖以下原语：

| 原语 | 工具/机制 | 说明 |
|------|----------|------|
| 创建子任务 | `kanban_create()` | 创建具有指定 `assignee` 的任务 |
| 依赖关系 | `kanban_link()` 或 `parents=[]` | 父任务完成 → 子任务自动晋升就绪 |
| 并行 | 多个 ready 子任务无相互依赖 | 调度器同时分派到不同 profile |
| 串行/汇合 | 子任务依赖先序任务 | 只有当所有 parents done 后才就绪 |
| 黑板通信 | `kanban_comment()` + `kanban_show()` | 任务之间通过评论传递结构化数据 |
| 工作区 | `workspace_kind` | scratch（临时）/ dir（持久目录）/ worktree（git） |

---

## 二、四种工作流模式

### 模式 A：并行扇出（Parallel Fan-out）

适用于：一个大型任务可拆分为多个独立子任务，并行执行。

```
               ┌─  Worker A (ready)
               │
    Orchestrator ── Worker B (ready)     ──→  Synthesizer (todo)
     (done)     │                              [等待所有 worker done]
               └─  Worker C (ready)
```

创建方式：

```python
# orchestrator 创建并行子任务
t1 = kanban_create(title="模块A", assignee="profile-a", parents=[root_id])
t2 = kanban_create(title="模块B", assignee="profile-b", parents=[root_id])
t3 = kanban_create(title="模块C", assignee="profile-c", parents=[root_id])

# 汇合任务：依赖于所有并行任务
synth = kanban_create(
    title="汇总结果",
    assignee="default",
    parents=[t1["task_id"], t2["task_id"], t3["task_id"]]
)
```

### 模式 B：流水线（Pipeline）

适用于：任务有明确的先后顺序，前一阶段的输出是后一阶段的输入。

```
    Worker A ──→ Worker B ──→ Worker C ──→ Worker D
    (done)      (done)       (done)        (done)
```

创建方式：

```python
t1 = kanban_create(title="阶段1", assignee="profile-a")
t2 = kanban_create(title="阶段2", assignee="profile-b", parents=[t1["task_id"]])
t3 = kanban_create(title="阶段3", assignee="profile-c", parents=[t2["task_id"]])
t4 = kanban_create(title="阶段4", assignee="profile-d", parents=[t3["task_id"]])
```

### 模式 C：DAG（有向无环图）

适用于：任务之间有交错依赖关系。

```
    ┌─ Worker A ─┐
    │            ├── Worker C ──→ Worker D
    └─ Worker B ─┘
```

创建方式：

```python
wa = kanban_create(title="A", assignee="profile-a")
wb = kanban_create(title="B", assignee="profile-b")
# kanban_link 添加依赖关系
kanban_link(parent_id=wa["task_id"], child_id=wc_id)
kanban_link(parent_id=wb["task_id"], child_id=wc_id)
```

### 模式 D：Swarm 拓扑

适用于：多路并行 → 验证 → 综合，适用于代码审查、论文审查等。

```
    Root (done)
    ├── Worker A (ready)
    ├── Worker B (ready)
    ├── Worker C (ready)
    └── Verifier (todo — 等所有 worker done)
        └── Synthesizer (todo — 等 verifier done)
```

内置命令：`hermes kanban swarm` 一键生成此拓扑。

### 模式 E：质量门控流水线（Quality-Gated Pipeline）

适用于：产出需要通过自检+审核+修复循环才能向下游流动的任务，每个实现节点配有审查节点形成质量闭环。

```
            T1: 实现 ──→ R1: 审查 ──→ 通过 → 下游
                              ↓
                            FAIL
                              ↓
                          FIX-T1 (返工)
                              ↓
                          R1-v2 再审
                            ├── 通过 → 下游
                            └── FAIL ×N → 组织替换
```

**核心原则：**
- T（实现者）：自检不通过不 complete
- R（审查者）：发现问题不走完
- 修复循环自相似 — T-R pair 的逻辑在 FIX-R-v2 上完全复用
- 组织替换 — 过审率过低时任务归档重建

详见 `references/quality-gated-pipeline.md`。

---

## 三、任务定义规范

### 任务标题

```
<动作> <领域/模块> [— 额外说明]
```

示例：
- `实现用户认证模块 — JWT + OAuth`
- `审查 PR #123 — 数据库迁移`
- `编写集成测试 — 支付网关`

### 任务正文（body）模板

```markdown
## Goal
（明确的目标描述）

## Approach
（建议的实现方法）

## Acceptance Criteria
- [ ] 标准1
- [ ] 标准2
- [ ] 标准3

## Context
（链接、参考、父级输出摘要）

## Output
（期望的产物：代码路径、文档路径、报告等）
```

### 子任务产出规范

每个子任务完成后，通过 `kanban_complete(metadata=...)` 传递结构化数据给下游：

```python
kanban_complete(
    summary="...",
    metadata={
        "changed_files": ["src/foo.py", "tests/test_foo.py"],
        "output_path": "/path/to/artifact.md",
        "key_decisions": ["选了 A 方案而非 B"],
        "blocking_issues": None,
    }
)
```

---

## 四、Profile 分配策略

| 场景 | 推荐 profile | 说明 |
|------|-------------|------|
| 前端开发 | `frontend-engineer` | React/Vue/CSS |
| 后端开发 | `backend-engineer` | API/数据库/业务逻辑 |
| 代码审查 | `code-reviewer` | PR review、安全检查 |
| 研究分析 | `researcher` | 文献搜索、竞品分析 |
| 文档编写 | `writer` | 文档、README、技术博客 |
| 测试 | `tester` | 单元测试、集成测试 |
| 运维部署 | `devops` | CI/CD、Docker、部署 |
| 综合汇总 | `default` | 收集并整合所有产出 |
| 分解器 | `planner` | 将大目标分解为子任务 |

---

## 五、手写编排 vs 自动分解

### 自动分解（推荐）

在 triage 状态创建任务，调度器自动调用 LLM 分解：

```bash
hermes kanban create "构建电商网站" \
  --assignee planner \
  --triage
```

调度器在下次 tick 中自动分解该 triage 任务为子任务图。

### 手动编排

适合已知固定流程的场景：

```python
root = kanban_create(title="项目 X", assignee="default")
t1 = kanban_create(title="模块A", assignee="profile-a", parents=[root["task_id"]])
t2 = kanban_create(title="模块B", assignee="profile-b", parents=[root["task_id"]])
final = kanban_create(
    title="整合",
    assignee="default",
    parents=[t1["task_id"], t2["task_id"]]
)
```

---

## 六、黑板通信机制

### worker 写入产出

```python
kanban_comment(
    task_id=root_task_id,
    body=json.dumps({"output": "接口地址: /api/v2/users", "schema": {...}})
)
```

### synthesizer 读取

```python
root = kanban_show(task_id=root_task_id)
# root.comments 包含所有 worker 的产出
```

### 推荐的黑板格式

```json
{
  "worker": "模块A",
  "status": "done",
  "artifacts": ["src/auth.py", "tests/test_auth.py"],
  "decisions": ["使用 JWT 而非 Session"],
  "notes": "需注意 Redis 连接池配置"
}
```

---

## 七、进度跟踪与心跳

| 工具 | 用途 | 频率 |
|------|------|------|
| `kanban_heartbeat(note="...")` | 长期任务保活 | 每小时至少 1 次 |
| `kanban_comment()` | 记录中间结果 | 关键里程碑 |
| `kanban_block(reason="...")` | 阻塞等待输入 | 遇到无法决策的问题 |

---

## 八、常用模式示例

### 示例 1：代码开发流水线

```
Specification (planner)
    │
    ├── Frontend (frontend-engineer)  — 并行
    ├── Backend  (backend-engineer)   — 并行
    │
    └── Integration Test (tester)     — 依赖前后端完成
        │
        └── Code Review (code-reviewer)
```

### 示例 2：研究综述

```
Research Plan (planner)
    │
    ├── 文献搜索 (researcher)     ── 并行
    ├── 技术对比 (researcher)     ── 并行
    │
    └── 综述撰写 (writer)          ── 依赖两项完成
```

### 示例 3：Bug修复紧急流程

```
Bug Report (triaged)
    │
    ├── 根因分析 (debugger)
    │       │
    │       ├── 修复代码 (backend-engineer)  — 依赖分析完成
    │       └── 写测试 (tester)               — 依赖分析完成
    │
    └── 部署验证 (devops)           ── 依赖修复+测试完成
```

---

## 九、最佳实践 & 注意事项

### DO

- 捕获所有 `kanban_create()` 返回值 — 后续依赖关系需要这些 task_id
- 用 `parents=[...]` 在创建时声明依赖 — 比事后 `kanban_link()` 更干净
- 用结构化 metadata 做手写 — 下游 worker 可以直接解析 metadata 而非评论
- 提前规划 profile — 确保每个子任务有正确的 assignee
- 长任务记得心跳 — 超过 1 小时必须发心跳

### DON'T

- 不要自己用父任务 ID 硬编码 — 从 `kanban_create()` 返回值获取真实 ID
- 不要创建虚假的 created_cards — 幻觉门会拒绝 phantom ID
- 不要让子任务超过父任务的 scope — 每个子任务应该只做一件事
- 不要忘记注入依赖关系 — 否则所有子任务会同时就绪
- 不要在 worker 内部调用 clarify — 要用 `kanban_block`

---

## 十、故障排查

| 问题 | 原因 | 解决 |
|------|------|------|
| 子任务一直 todo 不晋升 | 某个 parent 未完成 | `hermes kanban show <child_id>` 查看未完成的 parent |
| Worker 没有启动 | profile 不存在或凭证错误 | `hermes kanban diagnostics` 检查 |
| 任务卡在 running | worker 退出未 complete | `hermes kanban reclaim <task_id>` 回收 |
| 创建子任务报错 | 权限不足（非 orchestrator） | 确认 profile 有 `kanban` toolset |
| 幻觉门拒绝完成 | created_cards 中有不存在的 ID | 检查 `kanban_create` 返回值 |

---

## 附录：快速速查表

### 编排命令速查

```python
kanban_create(title="任务名", assignee="profile", parents=[...])  # 创建任务
kanban_link(parent_id="t_xxx", child_id="t_yyy")                  # 添加依赖
kanban_show(task_id="t_xxx")                                       # 查看状态
kanban_complete(summary="...", metadata={...})                     # 完成交付
kanban_block(reason="...")                                         # 阻塞
kanban_heartbeat(note="进度: 3/10")                                # 保活
kanban_comment(task_id="t_xxx", body=json.dumps({...}))            # 黑板通信
```

### 任务状态机

```
triage ──→ todo ──→ ready ──→ running ──→ done ──→ archived
               ↑                     ↑
               └── blocked ──────────┘
```

依赖机制：所有 parent 进入 done → child 从 todo 晋升到 ready
