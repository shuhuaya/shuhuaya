---
name: agent-org-workflow
description: 自组织树状工作流体系 — T-R 审核依赖链、组织替换/晋升职级、自检契约、蜂巢激励模型
version: 3.0.0
platforms: [windows]
metadata:
  hermes:
    tags: [kanban, workflow, self-organizing, review-system, agent-org, trust-capital]
---

# Agent 组织化工作流体系

> 基于蜂巢网络模型（Hive Blockchain）的激励设计。详情见 `references/hive-model.md`。
> 实操指南（TC 记账、callsign 管理、晋升执行）见 `references/implementation-guide.md`。

## 设计原则

1. **第一性原理** — 从源码和官方文档出发，不做推理假设。参考 `hermes_cli/kanban_db.py` 和 `gateway/run.py` 确认状态机和调度机制。
2. **离散自治** — 每个 agent 是独立组织，不依赖外部调度，只看板状态驱动。
3. **树状循环** — T-R pair 组成反馈环，失败后自修复，不线性推进。
4. **质量优先** — 过审率决定一切，高于数量。

## 核心架构：树状 T-R 依赖链

```
T1: 实现 → T2: 实现 → T3: 集成
  R1: 审查    R2: 审查    R3: 终审
```

每个 T（实现者）和一个 R（审查者）组成一对。T 自检通过后才 complete，R 通过后下游晋升。

## T Worker 自检纪律

T 内部循环：
```
T running → 干活 → 自检
  ↑              ↓
  └── 不通过 ────┘
  ↓
自检通过 → kanban_complete
```

自检不通过绝不 complete。T 必须自证质量过关才交产出。

## R Worker 审核标准

R 审核 T 的 metadata，逐条验证：
1. 文件存在性
2. 自检覆盖全部 AC
3. 功能实测
4. 判定 → complete 或 block

审核失败格式：`review-fail: 1.问题 2.问题`

## 组织替换机制

连续 2 次 review-fail → 归档旧组织 → 创建 T-v2（新策略）→ 重建依赖链 → 新组织上岗。

3 次组织更迭仍失败 → 上报用户。

---

## 蜂巢激励模型（Hive Model）

### Trust Capital（信任资本）

每个 agent 的 TC 衡量其历史贡献：

| 行为 | TC 变化 |
|------|---------|
| T 一次过审（自检+R一次通过） | +100 |
| T 返工后过审（有 FIX 循环） | +30 |
| R 正确发现真问题 | +50 |
| R 误判（T 实际没问题） | -40 |
| 组织被替换（归档） | 归零 |

TC 只看出**审结果质量**，不看干活数量。一次过 +100，返工过 +30。

### Task Budget（资源配额）

```
Budget = TC × 权重（默认 0.1）
每执行一个 task 消耗 budget:
  简单 task: 10      中等 task: 30      复杂 task: 50
Budget 每小时恢复 10%
Budget 耗尽 → agent 排队等恢复
```

高 TC 的 agent 能干更多复杂任务。低 TC 精打细算。被替换的新 agent TC=0。

### Delegation（担保机制）

高级 agent（Lv4+）可委托 TC 给低级 agent：

```
CPT-Phoenix (TC 6200)
  │ 委托 500 TC → OPR-Hammer (TC 350 → 850)
  │
  └── 若 OPR-Hammer 犯错，CPT-Phoenix 损失 50 TC
```

带人有风险，所以高级 agent 会认真指导。

### 晋升与奖励阶梯

| 层级 | 代号 | TC 门槛 | 晋升条件 | 奖励 |
|------|------|---------|----------|------|
| AGT | AGT-编号 | ≥0 | 首次过审 | 基础配额 |
| OPR | OPR-代号 | ≥300 | 3 次一次过审 | +优先调度 priority+1 |
| SGT | SGT-代号 | ≥800 | 累计 8 次一次过审 | +长工时 claim 30m |
| LT | LT-代号 | ≥2000 | 100%过审连续5次+审查过3任务 | **+个人记忆** +模型升级 +跳过小修改审查 |
| CPT | CPT-代号 | ≥5000 | 修过疑难问题 | +中等免审 +子任务权限 |
| MAJ | MAJ-代号 | ≥12000 | 主导完整项目链路 | +复杂免审 +额外技能槽 |
| COL | COL-代号 | ≥30000 | 20 次零返工 | +全上限 +标准制定权 |

### Callsign 命名规则

```
AGT-042             → 见习编号
OPR-Hammer          → 初级代号（首次获名）
SGT-Viper           → 中级代号
LT-Phantom          → 名前冠级
CPT-Phoenix         → 正式名号
MAJ-Spectre         → 称号级
COL-Titan           → 尊名级
```

每次晋升，原 callsign 记录在 agent 档案中。被替换的 agent 的 callsign 永久注销。

## 协调层职责

创建树 → dispatch 推进 → 检测 blocked（review-required，正常流转不干涉；review-fail，启动 FIX 循环）→ 检测失败替换组织 → 检测晋升条件授名授奖励 → 3 次失败上报用户。正常流转不打扰用户。