# Agent 组织系统实操指南

> 配套 `agent-org-workflow` SKILL.md 的实施细节。
> 概念模型（职级/TC/奖励）在 SKILL.md，操作流程在此。

## 核心约束

Hermes kanban 没有内置 TC 和职级字段。所有 agent 管理通过三种手段实现：

| 需要什么 | 实际用什么 |
|----------|-----------|
| Callsign 记录 | memory（`主 agent 记忆：agent roster`） |
| TC 台账 | memory + kanban run 历史 |
| 职级晋升 | 我手动创建 task + 更新 memory |
| 个人记忆（Lv4+） | `--tenant <callsign>` 传递给 worker |
| 调度优先级 | `--priority N` 控制 dispatch 顺序 |
| Task Budget | 手动估算，无自动化强制 |

## Agent Roster 格式

存在 memory 中，每次晋升/替换时更新：

```
agent-roster:
  AGT-042:
    callsign: OPR-Hammer
    rank: OPR
    tc: 350
    status: active
    created: 2026-05-31
   晋升记录:
      AGT-042 → OPR-Hammer  2026-05-31  3次一次过审
  AGT-043:
    callsign: (none)
    rank: AGT
    tc: 0
    status: probation
    created: 2026-06-01
```

## 晋升操作流程

```bash
# 1. 创建晋升 task（记录在 kanban 里）
hermes kanban create "晋升: AGT-042 → OPR-Hammer" \
  --assignee default \
  --body "理由：3次一次过审，TC已达350"

# 2. 更新 memory
# 用 memory 工具更新 roster

# 3. 后续该 callsign 的 task 用 --tenant OPR-Hammer
hermes kanban create "T: 实现X" \
  --assignee default \
  --tenant OPR-Hammer
```

## TC 记账规则

TC 不是实时自动计算的，是我在处理每次 R 的结果时手动记录的：

```
R block(review-fail) → TC -1（信誉分-1）
  ├── 第一次 → 创建 FIX → 循环
  ├── 第二次 → 触发组织替换
  └── 归档后 TC 归零

R complete → TC +1（信誉分+1）
  累计影响 → 到达阈值触发晋升评估
```

每次晋升后更新 roster 中的 TC 值。

## Task Budget 估算

Budget = TC × 10（即每 100 TC 可执行 1 个复杂任务）

无自动化强制，靠我在 dispatch 时手动判断。budget 耗尽时该 callsign 的任务延后处理。

## Delegation 实际行为

无自动化支持，全手动：

```bash
# 高级 agent 担保低级，实际效果：
# 在低级 agent 的 task 中加 --body 注明 "担保人: CPT-Phoenix"
# 低级犯错时我在 memory 中扣减 CPT-Phoenix 的 TC
# 不可替代缺失的自动化，但至少提供威慑和记录
```

## 替换操作

连续 2 次 review-fail → 执行组织替换（流程见 quality-gated-pipeline.md）：

```bash
hermes kanban archive <T_ID>
hermes kanban archive <R_ID>
hermes kanban create "T-v2: 重新实现" ... --body "新策略：..."
```
