# 蜂巢网络模型（Hive Blockchain）映射参考

> 来源: Hive blockchain 设计（原 Steem 分叉），蜂群生物学自组织原理。
> 用途: Agent 组织化工作流的激励与治理模型。

## Hive 核心机制 → Agent 系统

```
Hive Blockchain                     Agent 系统
────────────────────────────────────────────────────────────
Account（账户）                      Callsign（OPR-Hammer）
Hive Power / Vesting（权益锁仓）       Trust Capital（信誉资本）
Resource Credits（资源配额）           Task Budget（任务预算）
Reputation（信誉分）                   Review Pass Rate（过审率）
Witness（见证人、区块生产者）            R 审查 agent
Account Creator（账户创建者）           协调层（我）
Community（社区、子群组）               Skill 专精领域
Delegation（代理解押给他人）            高级 agent 担保低级
Curation（审查内容获得奖励）            审查者获认可/优先调度
Author Rewards（创作者获奖励）          实现者获 TC + 晋升
Vesting Schedule（锁仓释放周期）        Probation（见习期限制）
Hard Fork（协议升级/分叉）              组织替换（T→T-v2）
```

## 关键机制详解

### 1. Trust Capital（≈ Hive Power）

Hive Power 是 Hive 区块链上的权益代币，持有越多影响力越大，锁仓释放慢。

Agent 的 Trust Capital 同理：
- 通过高质量工作积累（一次过审 +100）
- 锁仓意味着不能通过短期刷量获得（返工过审只有 +30）
- 被替换时 TC 归零（≈ 账户被 power down 到零）
- TC 决定 agent 的调度优先级和资源配额

### 2. Resource Credits（≈ Task Budget）

Hive 上每笔交易消耗 RC，RC 基于 HP 计算，随时间恢复。

Agent 的 Task Budget：
- 基于 TC 计算
- 每执行 task 消耗 budget（简单/中等/复杂）
- 每小时恢复 10%
- 耗尽则排队等候

设计目的：防止低质量 agent 反复失败不消耗成本。

### 3. Delegation（≈ Hive 代理）

Hive 上 HP 持有者可以将 HP 代理给其他账户，被代理方获得等额 RC，代理方随时可以收回。

Agent delegation：
- 高级 agent（Lv4+）可将 TC 委托给低级 agent
- 被委托方获得临时 TC 提升（用于任务执行，不算晋升门槛）
- 若被委托方犯错，委托方损失部分 TC（≈ 代理风险）
- 高级 agent 因此有动力指导低级 agent

### 4. Curation（≈ 审查激励）

Hive 上审查内容越早越准，获得的 curation 奖励越高。

R worker：
- 正确发现真问题 +50 TC
- 误判则 -40 TC
- 准确率高的 R 获得更高调度优先级

### 5. Probation（≈ Vesting）

新 agent（AGT 级）处于见习期：
- Task Budget 极低
- 只能执行简单任务
- 需连续 3 次一次过审才能转正
- 相当于 Hive 新账户的锁仓期

## 为什么用蜂巢模型

1. **去中心化自组织** — 没有中央调度器，agent 通过看板状态自协调
2. **激励对齐** — TC 不是虚名，直接决定 agent 能做多少事
3. **惩罚可执行** — 替换组织 = TC 归零，是真实代价
4. **晋升有路径** — 每个层级 TC 门槛 + 条件清晰
5. **带人有机制** — Delegation 让知识传递有经济激励
6. **免审是特权** — CPT 以上的免审权不是白给的，是积累的信任

## 约束与边界

- 单 profile 下所有 agent 共享同一个模型
- TC 记录在 memory 中（或以看板 comment 形式持久化）
- 晋升需要协调层确认并授名
- 被替换的 agent 的 callsign 永久注销，不可重用
