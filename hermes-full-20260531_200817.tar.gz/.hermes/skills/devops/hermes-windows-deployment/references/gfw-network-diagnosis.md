# GFW Network Blocking Diagnosis (Discord Gateway)

**Origin session:** 2026-05-31 18:14 — User asked why agent also went offline after Discord bot disconnected.

## Symptoms

- `hermes gateway status` shows process running (PID 9568)
- Gateway log: `discord connect timed out after 30s`
- Gateway log: `Registered /skill command with 83 skill(s) via autocomplete` — token IS valid
- Gateway log: `Cannot connect to host discord.com:443 ssl:default [指定的网络名不再可用。]`
- curl to `discord.com:443`: SSL `Connection was reset` during handshake, HTTP code 000

## Diagnosis Sequence

```bash
# 1. Service check (Windows)
sc query HermesGateway
# STATE : 4  RUNNING = service is alive

# 2. Gateway log tail
tail -30 ~/.hermes/logs/gateway.log

# 3. DNS resolution
nslookup discord.com

# 4. Direct HTTPS test (watch for SSL reset)
curl -v --connect-timeout 10 https://discord.com/api/v10/gateway

# 5. Cross-site comparison
echo "baidu=$(curl -s -o /dev/null -w '%{http_code}' https://baidu.com)"
echo "google=$(curl -s -o /dev/null -w '%{http_code}' https://google.com)"
echo "github=$(curl -s -o /dev/null -w '%{http_code}' https://github.com)"
echo "opencode=$(curl -s -o /dev/null -w '%{http_code}' https://opencode.ai)"

# 6. System proxy check
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyEnable
netsh winhttp show proxy

# 7. Firewall
netsh advfirewall show allprofiles state

# 8. Hosts file (hijack check)
grep discord /c/Windows/System32/drivers/etc/hosts
```

## Key Finding Pattern

| Site | Status | Meaning |
|------|--------|---------|
| baidu.com | 301 | Chinese sites accessible |
| opencode.ai | 200 | Non-China sites that are NOT blocked also work |
| google.com | 000 | Blocked by GFW |
| github.com | 000 | Blocked/intermittently blocked by GFW |
| discord.com | SSL reset | Actively RST'd by GFW mid-handshake |

## No Proxy Installed

Checked for: Clash, v2ray, trojan, sslocal, ssr, hysteria, nekoray, sing-box, xray, proxifier. None found.

No TUN/TAP adapters. No system proxy. No environment variable proxies.

## Fix: DISCORD_PROXY (Correct Method)

The Hermes Discord adapter (`plugins/platforms/discord/adapter.py`) reads `DISCORD_PROXY` env var — **not** `HTTP_PROXY`/`HTTPS_PROXY`. Setting the generic env vars has no effect on discord.py's aiohttp connections.

```bash
# ✅ CORRECT — set for nssm service:
nssm set HermesGateway AppEnvironmentExtra DISCORD_PROXY=socks5://127.0.0.1:10808

# ❌ WRONG — discord.py's aiohttp does NOT use these:
nssm set HermesGateway AppEnvironmentExtra HTTP_PROXY=socks5://127.0.0.1:10808
```

### Steps

1. Connect VPN/proxy (e.g., 蓝莓加速 at `E:\blueberryVPN\blueberryVPN.exe`)
2. Verify proxy port is listening: `netstat -ano | grep 10808`
3. Test Discord through proxy: `HTTPS_PROXY=socks5://127.0.0.1:10808 curl -s -o /dev/null -w '%{http_code}' https://discord.com/api/v10/gateway` → expect `200`
4. Set `DISCORD_PROXY` on nssm: `nssm set HermesGateway AppEnvironmentExtra DISCORD_PROXY=socks5://127.0.0.1:10808`
5. Add to `~/.hermes/.env`: `echo 'DISCORD_PROXY=socks5://127.0.0.1:10808' >> ~/.hermes/.env`
6. Kill ALL old gateway pythonw.exe processes using real PIDs from `tasklist`:
   ```bash
   tasklist //FI "IMAGENAME eq pythonw.exe" //FO LIST
   # Get the PID, then:
   taskkill //PID <PID> //F
   ```
7. Restart: `net stop HermesGateway && net start HermesGateway`
8. Wait 15s, verify: `grep 'Connected as' ~/.hermes/logs/gateway.log` → expect `Connected as BotName#1234`

## Architecture Note: "Agent went offline" has two distinct causes

When the user reports "the agent went offline," distinguish:

| Cause | Symptoms | Logs | All channels down? |
|-------|----------|------|--------------------|
| Gateway process crash/exit | No response anywhere — CLI, Discord, all platforms dead | `gateway-exit-diag.log` shows exit/crash; `gateway.log` stopped | YES |
| Discord platform connection failure | CLI works, only Discord unresponsive | `gateway.log`: `discord connect timed out` with GFW pattern | NO — only Discord |

The user may ask "why did the model itself go offline" when they mean the Discord channel is down. But they may also genuinely mean the whole process was down (gateway crash). Always check both — don't dismiss the question as just a Discord issue.

### Verify proxy is working

```bash
# Through the proxy
curl -x socks5://127.0.0.1:10808 -s -o /dev/null -w '%{http_code}' \
  --connect-timeout 10 https://discord.com/api/v10/gateway
# Expected: 200 (or any HTTP response — means TCP/SSL reached Discord)
```
