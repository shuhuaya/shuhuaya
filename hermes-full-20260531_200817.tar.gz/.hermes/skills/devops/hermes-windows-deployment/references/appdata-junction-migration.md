# AppData Junction Migration (C: → D:)

When C: drive is full and D: has free space, move large AppData directories and replace with junctions so applications continue working without reinstall.

## Prerequisites

- **Admin rights** (junction creation requires elevation)
- Target application must be **closed** (no file locks)

## Step-by-Step

### 1. Identify large AppData directories

```bash
cd /c/Users/Administrator/AppData/Local
for d in */; do
  sz=$(du -sh "$d" 2>/dev/null | cut -f1)
  echo "$sz  $d"
done | sort -rh | head -15
```

### 2. Move directory + create junction

Python method (recommended — handles errors gracefully):

```python
import os, subprocess, shutil

def move_with_junction(src, dst, label):
    """Move dir to D: and create junction"""
    if not os.path.exists(src):
        print(f"{label}: not found")
        return

    # Check if already a junction
    r = subprocess.run(["fsutil", "reparsepoint", "query", src],
                       capture_output=True, text=True, errors='replace')
    if "reparse" in r.stdout.lower():
        print(f"{label}: already a junction ✓")
        return

    # 1. Create target
    os.makedirs(dst, exist_ok=True)

    # 2. Copy everything (robocopy for reliability)
    r = subprocess.run(["robocopy", src, dst, "/MIR", "/NJH", "/NJS", "/NDL", "/NP"],
                       capture_output=True, text=True, errors='replace')

    # 3. Delete original with force
    subprocess.run(["cmd", "/c", f'rd /s /q "{src}"'],
                   capture_output=True, text=True, errors='replace')

    # 4. or use shutil.move (simpler but may fail on locked files)
    shutil.move(src, dst)

    # 4. Create junction
    subprocess.run(["cmd", "/c", f'mklink /J "{src}" "{dst}"'],
                   capture_output=True, text=True, errors='replace')
```

### 3. Common targets

| Directory | Size (typical) | Safe? |
|-----------|---------------|-------|
| `AppData\Local\JianyingPro` | 2-3 GB | Yes (剪映专业版) |
| `AppData\Local\Doubao` | 1-2 GB | Yes (豆包) |
| `AppData\Local\NetEase` | 1-2 GB | Yes (网易云/网易邮箱) |
| `AppData\Local\Google\Chrome\User Data\Default\Cache` | 500 MB+ | Yes (Chrome cache) |

## Verification

```bash
# Check the junction exists
dir /c/Users/Administrator/AppData/Local/JianyingPro
# Should show <JUNCTION> in listing

# Check original path still works
ls -la /c/Users/Administrator/AppData/Local/JianyingPro/
```

## Pitfalls

- **File locks** — If the app is running, junction creation fails with "Access denied". Kill the app first.
- **Junction requires admin** — `mklink /J` needs elevated cmd. Python script running under admin works.
- **Not all apps support junctions** — Some apps check real path and break. Test after migration.
- **Cannot junction across different filesystem types** — Both paths must be NTFS.
- **`shutil.move` across drives** copies then deletes, not renames. This is fine but takes time for large dirs.
