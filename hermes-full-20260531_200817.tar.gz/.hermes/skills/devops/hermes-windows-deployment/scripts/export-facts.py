#!/usr/bin/env python3
"""Export Hermes Fact Store to readable text file for backup."""
import sqlite3, os, sys
from datetime import datetime

db_path = os.path.expanduser('~/.hermes/memory_store.db')
out_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser('/d/hermes-backup-tmp')

if not os.path.exists(db_path):
    print('[Export] No fact store found')
    sys.exit(0)

conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
rows = conn.execute(
    'SELECT category, content, tags, trust_score, created_at FROM facts ORDER BY created_at'
).fetchall()

out_path = os.path.join(out_dir, 'fact_store_export.txt')
with open(out_path, 'w', encoding='utf-8') as f:
    f.write('=== Hermes Fact Store Export ===\n')
    f.write(f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
    f.write(f'Total facts: {len(rows)}\n')
    f.write('=' * 60 + '\n\n')
    for r in rows:
        f.write(f'--- [{r["category"] or "uncategorized"}] ---\n')
        if r['tags']:
            f.write(f'Tags: {r["tags"]}\n')
        f.write(f'Trust: {r["trust_score"]} | Created: {r["created_at"]}\n\n')
        f.write(r['content'] or '')
        f.write('\n' + '-' * 40 + '\n\n')

print(f'[Export] Written {len(rows)} facts to {out_path}')
conn.close()
